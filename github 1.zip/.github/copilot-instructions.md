# SMAPI iOS Analytics SDK — Copilot Instructions

> Auto-loaded every request. Keep short. Load feature docs **only** when the task touches that feature.

## 1. What this SDK is
Measures app performance + ships analytics events to a central backend. Three Swift modules + sample app:
`SecLibUtilities` ← `SecLibCore` ← `SecLibAnalytics` ← `SecLibAnalyticsSample`.

## 2. Path aliases

| Alias | Path | Purpose |
| --- | --- | --- |
| `@core` | `SecLibAnalyticsSDK/CoreSDK/SecLibCore/` | `SecLib`, `Configuration`, `CoreManager`, `SessionIDManager` |
| `@core.ana` | `SecLibAnalyticsSDK/CoreSDK/SecLibCore/Analytics/` | **Analytics that runs IN Core:** URLSession/UIControl/UIScene/UIView swizzling, SwiftUI `secLibTrackedItem`, `NetworkTrackingManager`, `EventData`, `TrackedDataTask` |
| `@ana` | `SecLibAnalyticsSDK/SecLibAnalytics/` | `CoreAnalyticsManager`, `SecLib+Analytics` (public-API extension), storage, hangs, flush |
| `@util` | `SecLibAnalyticsSDK/CoreSDK/UtilitiesSDK/SecLibUtilities/SecLibUtilities/` | `SLLogger`, `UtilityManager`, `RepeatingTimerManager`, `PerformanceCalculator` |
| `@sample` | `AnalyticsSampleApp/` | Integration reference |
| `@tests.core` / `@tests.ana` | `…/SecLibCoreTests/` / `SecLibAnalyticsTests/` | Unit tests |

**Modularity rule:** `SecLib` is declared in `@core/SecLib/SecLib.swift`, extended in `@ana/Managers/SecLib+Analytics.swift`. Every analytics API on `SecLib` forwards `getAnalytics()?.…` → `CoreAnalyticsManager` (@ana) → `CoreManager` (@core) when it needs Core services. Sub-folders in every module: `Managers/`, `Model(s)/`, `Extensions/`, `Utilities/`.

**Multi-instance rule (non-negotiable — see [features/MultiInstance/](features/MultiInstance/copilot-multi-instance.md)):** the SDK supports N `SecLib` instances in one process, keyed by `appName`. Each has its own `CoreAnalyticsManager`, `EventHandler`, `UserDefaults` suite, HomeDoc/settings cache, and submit URL. CoreData is a single store partitioned by `appName` column. Swizzling, session ID, and hang monitors are shared. **Every new feature must state up-front whether it is per-instance (default) or shared, and follow the contract in that doc.**

**Module registration rule** (for any new add-on SDK — see [features/ModuleRegistration/](features/ModuleRegistration/copilot-module-registration.md)): every non-Core SDK ships an obj-c `+load` loader that instantiates a `SecLibrary`-conforming class and calls `startLogic()`, which registers via `SecLib.registerComponent(self)`. At `SecLib.setup(...)`, the core matches each registered `SecLibrary.name` against `Configuration.components[…].key` and calls `configure(with:core:)`. Only `Core.startLogic()` installs swizzling — no other module should. The full "add a new SDK module" checklist lives in that doc.

Design patterns: **Facade** (`SecLib`), **Mediator** (`CoreManager` / `CoreAnalyticsManager`), **Builder** (`Configuration.Builder`).

## 3. Feature index — load a doc only when you need it

| Feature | Entry point API | Modules | Doc |
| --- | --- | --- | --- |
| SDK setup & configuration | `SecLib.setup(withConfiguration/withPath/withName:)` | `@core` | [instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) + [flowchart](instructions/SecLibCoreSetup/copilot-secLib-setupFlowChart.md) |
| Enable / disable analytics | `secLib.enableAnalytics` | `@core`,`@ana` | [features/EnableDisableAnalytics/](features/EnableDisableAnalytics/copilot-enable-disable-analytics.md) |
| Custom event logging | `logCustomEvent(withEventElement:…)` | `@core`→`@ana` | [features/LogCustomEvent/](features/LogCustomEvent/copilot-log-custom-event.md) + [flowchart](features/LogCustomEvent/copilot-log-custom-event-flowchart.md) |
| Event pipeline (`logEvent(_:)`) | `CoreAnalyticsManager.logEvent(_:)` | `@ana` | [features/AnalyticsManager/](features/AnalyticsManager/copilot-setup-logEvent.md) |
| **Multi-instance (`SecLib` per `appName`)** | `SecLib.setup(…, name:)` / `SecLib.getInstance(withName:)` — separate `CoreAnalyticsManager`, `EventHandler`, UserDefaults suite, HomeDoc/settings, submit URL; shared swizzling, CoreData store (partitioned by `appName`), session ID, hang monitors | `@core` + `@ana` | [features/MultiInstance/](features/MultiInstance/copilot-multi-instance.md) — **read before adding any new feature** |
| **SDK module registration (`SecLibrary` + loaders)** | `+load` → `<Module>.startLogic()` → `SecLib.registerComponent(self)`; `SecLib.setup(...)` fans out to `configure(with:core:)` per matched key | `@core` + `<Module>` | [features/ModuleRegistration/](features/ModuleRegistration/copilot-module-registration.md) — **read before adding a NEW SDK module (Crashes / CustomerChannel / …)** |
| **Auto-instrumentation (swizzling)** | `Core.startLogic()` / `enableSwizzling()` | `@core.ana` → `@ana` | [features/AutoInstrumentation/](features/AutoInstrumentation/copilot-auto-instrumentation.md) — read for cross-feature bugs (UIControl / TableView / CollectionView / screen load / stay time / network) |
| **Event storage + flush + PII masking** | `CoreDataManager` / `EventHandler` / `DynamicPII` — **defaults are only fallbacks; real values come from HomeDoc → Settings response** (10 events \| 30 s \| 1000 DB \| 3000 sent \| 50/batch; PII default `\d{9}` on `Network` → `MASKEDMSISDN`) | `@ana` (settings fetched by `@core`) | [features/EventStorage/](features/EventStorage/copilot-event-storage.md) |
| Measure load time / app launch (**manual**) | `startTimer(...)` / `stopTimer(...)` | `@core`→`@ana` | [features/MeasureLoadTime+AppLaunch/](features/MeasureLoadTime+AppLaunch/copilot-measure-load-time.md) + [flowchart](features/MeasureLoadTime+AppLaunch/copilot-measure-load-time-flowchart.md) |
| Screen load time + stay time (**auto**, per VC) | `UIViewController` lifecycle swizzles → `ViewControllerCalculator` | `@core.ana` → `@ana` | [features/AutoInstrumentation/](features/AutoInstrumentation/copilot-auto-instrumentation.md) §4.4 |
| UIControl / TableView / CollectionView auto-tracking | `UIApplication.sendAction`/`sendEvent` + `UITableView`/`UICollectionView` delegate swizzles | `@core.ana` → `@ana` | [features/AutoInstrumentation/](features/AutoInstrumentation/copilot-auto-instrumentation.md) §4.1–4.3 |
| Network monitor | `setConfigureNetworkMonitoring(...)` / `get...()` | `@core`→`@ana` | [features/NetworkMonitor/](features/NetworkMonitor/copilot-network-monitor.md) + [flowchart](features/NetworkMonitor/copilot-network-monitor-flowchart.md) |
| Network request details | `AnalyticsConfiguration(trackRequestDetails:)` | `@core`,`@ana` | [features/NetworkRequestDetails/](features/NetworkRequestDetails/copilot-network-request-details.md) |
| Manual network event | `requestMetrics(...)` + `logResponse(...)` | `@core`,`@ana` | [features/ManualNetworkEvent/](features/ManualNetworkEvent/copilot-manual-network-event.md) |
| Ignored domains | `throtleLocalEndPoint(endPoint:)` | `@core`,`@ana` | [features/IgnoredDomains/](features/IgnoredDomains/copilot-ignored-domains.md) |
| Custom UI trace | `startUITrace(withName:)` / `endUITrace()` | `@ana` | [features/CustomUITrace/](features/CustomUITrace/copilot-custom-ui-trace.md) |
| UI hangs tracking | `setUIHangMonitor(...)` / `getUIHangStatus()` | `@ana` | [features/UIHangs/](features/UIHangs/copilot-ui-hangs.md) |
| App hang detection | `AppHangConfiguration(enabled:threshold:)` | `@ana` | [features/AppHang/](features/AppHang/copilot-app-hang.md) |
| Screen name | `setScreenName(screenName:)` | `@core` | [features/ScreenName/](features/ScreenName/copilot-screen-name.md) |
| SwiftUI item tracking | `.secLibTrackedItem()` | `@core.ana` | [features/SwiftUITracking/](features/SwiftUITracking/copilot-swiftui-tracking.md) |
| Session ID | `getCurrentSessionID()` / `subscribeToSessionID` | `@core` | [features/SessionID/](features/SessionID/copilot-session-id.md) |
| Native → Web session transfer | `appendSession(for: url)` | `@ana` | [features/TransferSessionID/](features/TransferSessionID/copilot-transfer-session-id.md) |
| Trace ID key mapping | `setTraceIdKey(traceKey:)` | `@core`,`@ana` | [features/TraceIDKey/](features/TraceIDKey/copilot-trace-id-key.md) |
| Custom user ID | `setUserID(...)` / `getUserID()` | `@core` | [features/CustomUserID/](features/CustomUserID/copilot-custom-user-id.md) |
| Log components | `logComponents([name: version])` | `@ana` | [features/LogComponents/](features/LogComponents/copilot-log-components.md) |
| Obfuscate request fields | `obfuscatedRequests(list:)` | `@ana` | `@ana/Managers/SecLib+Analytics.swift:270` → `CoreAnalyticsManager.setObfuscatingRequests(lists:)` |
| Obfuscate response fields | `obfuscatedResponses(list:)` | `@ana` | `@ana/Managers/SecLib+Analytics.swift:282` → `CoreAnalyticsManager.setObfuscatingResponses(lists:)` |

## 4. Setup config cheat sheet — where each feature is configured

Every setup-time knob lives on `AnalyticsConfiguration` (`@ana/Model/AnalyticsConfiguration.swift:16`) and is either passed to `Configuration.Builder.addConfiguration(_:)` or read from `smapi-config.json` under `"analytics": {…}`. Full setup flow: [instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Module handshake: [features/ModuleRegistration/](features/ModuleRegistration/copilot-module-registration.md).

| Feature | `AnalyticsConfiguration` param | `smapi-config.json` key (under `analytics`) | Default | Nested config type |
| --- | --- | --- | --- | --- |
| Enable / disable analytics | `enabled` | `enabled` | `true` | — |
| Network monitor | `networkMonitor` | `networkMonitor` | `false` | — |
| ViewController lifecycle tracking (drives auto interaction events + screen load/stay time observer registration) | `viewLifeCycleTrackedEnabled` | `viewLifeCycleTrackedEnabled` | `true` | — |
| UI hangs | `uiHangsEnabled` | `track_ui_hangs` | `true` | — |
| Network request details (headers/bodies) | `trackRequestDetails` | `track_request_details` | `false` | — |
| App hang | `appHang` | `app_hang` | fresh `AppHangConfiguration()` | `AppHangConfiguration(enabled: Bool = false, threshold: Double = 3.0)` — JSON: `app_hang.track_app_hangs`, `app_hang.threshold` |

**Runtime-only features** (no builder knob — set on an already-created `SecLib` instance): custom event, timers, screen name, user ID, session ID, custom UI trace, ignored domains, trace ID key, transfer session, log components, manual network event, obfuscation, SwiftUI item tracking. These require the SDK to be set up first — see the setup doc above.

**Server-side settings** (overriding SDK defaults at runtime via HomeDoc → Settings response): flush cadence, DB/send caps, PII regex, blocking rules. See [features/EventStorage/](features/EventStorage/copilot-event-storage.md#where-these-settings-come-from--homedoc--settings--override-defaults).

## 5. End-to-end event flow
```
App → SecLib (@core class, extended in @ana) → NotificationCenter (name = <notif> + "-" + appName)
    → CoreAnalyticsManager (@ana) → PII mask → Event → CoreData (SecLibDB.xcdatamodeld) → flush
```
Every event lands in `logEvent(_:)` at `@ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:56` (guard: `enabled && coreManager.smapiEnable`). **This is your #1 breakpoint.** Post-`logEvent(_:)` persistence + flush cadence: [features/EventStorage/](features/EventStorage/copilot-event-storage.md). All swizzles installed in [features/AutoInstrumentation/](features/AutoInstrumentation/copilot-auto-instrumentation.md).

## 6. Debug + work-on-feature workflow

1. **Confirm scope** — ask which row in §3 is affected if unclear.
2. **Find the entry point.** Pure Core APIs (session ID, screen name, user ID, `logCustomEvent`, base `setup/enabled`) → `@core/SecLib/SecLib.swift`. Analytics APIs → `@ana/Managers/SecLib+Analytics.swift`.
3. **Follow `getAnalytics()?.…`** into `@ana/Managers/AnalyticsManager/CoreAnalyticsManager(+Extension).swift`. If it delegates back into Core, continue into `@core/Managers/CoreManager/*.swift`.
4. **Config-driven?** Check `AnalyticsConfiguration` (`@ana/Model/AnalyticsConfiguration.swift`) + JSON decoding.
5. **Notification wiring?** All names in `enum Notifications` at `@core/CoreUtility/Constants.swift:41`. Observers register in `CoreAnalyticsManager.addEventObservers()` at `@ana/…/CoreAnalyticsManager.swift:273`.
6. **Load only the matching feature doc**, plus its flowchart if present. Don't preload others.
7. **Standards (agent mode when writing/editing code — skip in ask mode):** open [instructions/copilot-code-instructions.md](instructions/copilot-code-instructions.md) and load **only** the topic file(s) under [instructions/code/](instructions/code/) that match what you're about to change (naming vs formatting vs memory vs …) — not the whole tree. Test conventions: [instructions/copilot-unit-testing-instructions.md](instructions/copilot-unit-testing-instructions.md) (naming pattern `test_<feature>_<scenario>_return<ExpectedResult>`).
8. **Before implementing** new public API, config-schema, notification-name, CoreData-model, or cross-module changes — propose the plan (1–3 bullets) and wait. **Always call out whether the feature is per-instance or shared** (see [features/MultiInstance/](features/MultiInstance/copilot-multi-instance.md) — per-instance is the default; shared needs a reason).

## 7. Retained standards (linked)
- **Coding — index of topic-scoped rules** (load only the topic that matches your change, and only in **agent mode when writing/editing code** — skip in ask mode): [instructions/copilot-code-instructions.md](instructions/copilot-code-instructions.md). Topics live under [instructions/code/](instructions/code/) — naming, organization, formatting, types, functions, memory, access-control, control-flow, project-conventions.
- Unit testing: [instructions/copilot-unit-testing-instructions.md](instructions/copilot-unit-testing-instructions.md)
- Submodule setup: [prompt/prompt-setup-submodules.md](prompt/prompt-setup-submodules.md)
- PR template: repo-level `.github/PULL_REQUEST_TEMPLATE.md` · SwiftLint: `.swiftlint.yml` (authoritative for formatting)

## 8. Copilot rules
- Use §2 aliases when talking about paths.
- Reference code as `path:line` so the user can click.
- Never restate coding/testing/setup — link.
- Multiple features could apply? List candidates (row names) and ask.

## 9. Maintenance
- New feature → one row in §3 + a lean doc under `features/<Name>/`. Template: [features/EnableDisableAnalytics/copilot-enable-disable-analytics.md](features/EnableDisableAnalytics/copilot-enable-disable-analytics.md). Shape: entry-point table → call graph → debug table → enhancing → related.
- **Every new feature doc must state its multi-instance scope** — either "per-instance (state on `CoreAnalyticsManager` / `CoreManager`, notifications suffixed with `-<appName>`)" or "shared across instances (static on `SecLib`; broadcast events; filter in handler)". Follow the contract at [features/MultiInstance/](features/MultiInstance/copilot-multi-instance.md).
- **New SDK module** (Crashes, Rating, CustomerChannel, …) → follow the loader + `SecLibrary` + `Configurable` checklist at [features/ModuleRegistration/](features/ModuleRegistration/copilot-module-registration.md). Register a `SecLibrary` in `+load` via `startLogic()`; expose a `Configurable` whose `key == SecLibrary.name`; keep per-instance state in a `SecLib.<module>Managers[appName]` static registry.
- Renamed/removed API → update/delete the row same PR.
