# Analytics Event Pipeline — `logEvent(_:)`

**All events funnel here.** Custom events, timers, network capture, hangs, `logComponents` → this single method handles masking, blocking, persistence, and flush.

## Key locations
| Symbol | File / Line |
| --- | --- |
| `logEvent(_ eventData:)` | `@ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:56` |
| `applyPII(forEventDescription:type:)` | `…+Extension.swift:121` |
| `createEvent(_:maskedPIIDesc:)` | `…+Extension.swift:94` |
| `eventBlockingCheck(blacklist:whitelist:for:)` | `…+Extension.swift:184` |
| `addEvent(_:)` (private) | `…+Extension.swift:84` |
| `EventHandler.checkNextFlush()` | `@ana/Managers/EventHandler.swift:132` |
| Event model / CoreData / PII rules | `@ana/Model/Event.swift` · `@ana/Managers/CoreData/CoreDataManager(+Event).swift` · `@ana/Model/DynamicPII.swift` |

## Flow
```
logEvent(_ eventData:)                                    @…+Extension.swift:56
  ├ guard enabled && coreManager.smapiEnable else return    (:57)   ← #1 debug breakpoint
  ├ maskedPIIDesc = applyPII(…)                             (:60, impl :121)
  └ DispatchQueue.main.async:
      ├ event = createEvent(eventData, maskedPIIDesc:)      (:64, impl :94)
      ├ status = eventBlockingCheck(blacklist, whitelist,
      │            for: event.generatePayload())            (:66, impl :184)
      ├ if status != .allowed → log + return                (:71-77)
      └ queue.async → addEvent(event)                       (:78, impl :84)
          ├ storage.save (CoreData)
          └ EventHandler.checkNextFlush() → batch → PostEventRequest → backend  (:132)
```

## Settings origin (masking + blocking + flush cadence)

`storage.settings` (an `AnalyticsSetting`) drives PII regex, blacklist/whitelist, and every flush/cap constant used here. It is **loaded from the backend HomeDoc → Settings request** and **overrides the defaults declared in `@ana/Model/AnalyticsSetting.swift`**. Fetch entry point: `startRequestEntryPoints(_:completion:)` @ `@core/Managers/CoreManager/CoreManager.swift:222`. Merge site: `AnalyticsSetting.init(from:)` @ `@ana/Model/AnalyticsSetting.swift:32` (`updateIfPresent` — missing key → default kept, present key → overwritten). Full details: [../EventStorage/copilot-event-storage.md](../EventStorage/copilot-event-storage.md#where-these-settings-come-from--homedoc--settings--override-defaults).

## Where to look when debugging
| Symptom | Check |
| --- | --- |
| Event silently disappears | Breakpoint the early-return at `:57` — #1 cause. |
| PII not masked | `applyPII` `:121` reads `storage.settings.dynamicPII` (overridden from HomeDoc). Event `type` must be in `dynamicPII.eventType`. Regex + default in `@ana/Model/DynamicPII.swift`. |
| Locally allowed, backend rejects | Stale blocking settings — settings were fetched from HomeDoc via `@core/Managers/CoreManager/CoreManager.swift:222`. 7-day refresh throttle at `:245`. |
| DB grows, no flush | Throttle in `checkNextFlush()` `:132` or network failure — see [EventStorage](../EventStorage/copilot-event-storage.md#flush-path). |
| Duplicate persistence | Two upstream sources both invoked `logEvent(_:)` — dedupe upstream, not here. |
| Log shows `<status>\n<json>\n` | `eventStatus.rawValue` != `.allowed` — status text says why. |
| Backend override ignored | JSON key mismatch — see `CodingKeys` at `@ana/Model/AnalyticsSetting.swift:51`. |

## Enhancing
- New blocking rule → extend `EventBlockingStatus` (`@ana/Utilities/Enums/EventBlockingStatus.swift`) + `eventBlockingCheck` `:184`.
- Swap persistence → replace `AnalyticsStorageManager` / `CoreDataManager+Event.swift`; leave `logEvent` untouched.
- Pre-persist telemetry → add inside `addEvent(_:)` `:84` before `storage.save`.
- **Never bypass `logEvent(_:)`.** Every source must funnel through it so blocking + masking always apply.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md). Config handshake into `CoreAnalyticsManager`: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).
- **Storage + flush cadence (defaults + caps):** [../EventStorage/](../EventStorage/copilot-event-storage.md)  
- **Auto-capture sources:** [../AutoInstrumentation/](../AutoInstrumentation/copilot-auto-instrumentation.md)  
- Sources: [../LogCustomEvent/](../LogCustomEvent/copilot-log-custom-event.md) · [../MeasureLoadTime+AppLaunch/](../MeasureLoadTime+AppLaunch/copilot-measure-load-time.md) · [../NetworkMonitor/](../NetworkMonitor/copilot-network-monitor.md) · [../LogComponents/](../LogComponents/copilot-log-components.md) · [../EnableDisableAnalytics/](../EnableDisableAnalytics/copilot-enable-disable-analytics.md)
