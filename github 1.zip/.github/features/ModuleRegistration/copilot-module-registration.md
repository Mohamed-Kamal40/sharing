# SDK Module Registration (`SecLibrary` protocol + loaders)

Every add-on SDK (Analytics, Crashes, CustomerChannel, …) plugs into `SecLib` via the same three-step pattern:

1. **Objective-C `+load`** in a loader class runs before `main()` and calls the module's `startLogic()`.
2. **`startLogic()`** does one of two things:
   - **Core only** — installs method swizzling.
   - **Every other module** — registers itself with `SecLib.registerComponent(self)` (conforms to `SecLibrary`).
3. **On `SecLib.setup(...)`** — the core iterates `SecLib.components`, matches each against `Configuration.components` by key, and calls `configure(with:core:)` on the matching module.

## Contract types

| Symbol | File / Line | Role |
| --- | --- | --- |
| `protocol SecLibrary` | `@core/SecLib/SecLibrary.swift:11` | `func configure(with configuration: [String: Any], core: CoreManagerProtocol)` + `var name: String { get set }` |
| `protocol Configurable` | `@core/Models/Configuration.swift:12` | `var key: String { get set }` + `func build() -> [String: [String: Any]]?` — used on the config object side |
| `class Configuration` | `@core/Models/Configuration.swift:22` | Holds `components: [[String: Any]]` — the list of per-module config dicts |
| `class Configuration.Builder` | `@core/Models/Configuration.swift` (nested) — `addConfiguration(_:)` @ `:98` | Appends each module's config dict (deduped by key) |
| `class SecLib` component registry | `SecLib.components: [SecLibrary]` (static) @ `@core/SecLib/SecLib.swift:17` |
| `SecLib.registerComponent(_:)` | `@core/SecLib/SecLib.swift:26` | Append-only |
| `SecLib.setup(config:name:)` — fan-out | `@core/SecLib/SecLib.swift:296` | `for lib in components; for configComponent in config.components where configComponent[lib.name] != nil → lib.configure(with: configComponent, core:)` |

## Two loader flavors

### Flavor A: Core loader (installs swizzling only)
```objc
// @core/SecLib/CoreSecLibLoader.m
#import "CoreSecLibLoader.h"
#import <SecLibCore/SecLibCore-Swift.h>

@implementation CoreSecLibLoader
+ (void)load {
    NSLog(@"SecLib: Core Loaded");
    [[[Core alloc] init] startLogic];   // → Core.startLogic() @ @core/Managers/Core.swift:14
}
@end
```
```swift
// @core/Managers/Core.swift
public class Core: NSObject {
    @objc public func startLogic() {
        enableSwizzling()                 // installs URLSession + UIControl + VC + Table/Collection swizzles
    }
    private func enableSwizzling() { … }  // see AutoInstrumentation doc
}
```
Core does **not** conform to `SecLibrary`. It doesn't register — it's the host. Its `startLogic()` only wires the auto-capture layer.

### Flavor B: Add-on module loader (registers `SecLibrary`)
```objc
// @ana/SecLibLoader/AnalyticsSecLibLoader.m
+ (void)load {
    NSLog(@"SecLib: Analytics Loaded");
    [[[Analytics alloc] init] startLogic];   // → Analytics.startLogic() @ @ana/Managers/Analytics.swift:29
}
```
```swift
// @ana/Managers/Analytics.swift
public class Analytics: NSObject, SecLibrary {
    public var name: String = AnalyticsConfigKeys.analytics    // "analytics"  @ @ana/Utilities/Constants.swift:48

    public func configure(with configuration: [String: Any], core: CoreManagerProtocol) {
        SLMessageLog("Setup Analytics with configuration \(configuration)", appName: core.appName, level: .info)
        SecLib.configure(with: configuration, core: core)      // module's own setup logic; here → @ana/Managers/SecLib+Analytics.swift:26
    }

    @objc public func startLogic() {
        SecLib.registerComponent(self)                          // append to SecLib.components
    }
}
```
Two obligations:
- **`name`** must be the same string the module's `Configurable` uses as its `key` (so the fan-out matches). For Analytics that's `"analytics"` (`AnalyticsConfigKeys.analytics`) — also the `key` on `AnalyticsConfiguration` @ `@ana/Model/AnalyticsConfiguration.swift:17`.
- **`configure(with:core:)`** is called once per matching config dict per `SecLib.setup(...)`. This is where the module builds its per-instance state (e.g. Analytics creates `CoreAnalyticsManager` and stores it in `SecLib.analyticsManagers[core.appName]`).

## Bootstrap timeline

```
App linked → all frameworks' +load methods run (order not guaranteed):
   CoreSecLibLoader.+load     → Core().startLogic() → enableSwizzling()      (installs class-level hooks)
   AnalyticsSecLibLoader.+load → Analytics().startLogic() → SecLib.registerComponent(<Analytics>)
   (any other module loader)   → <Module>().startLogic() → SecLib.registerComponent(<Module>)

App runs main() → AppDelegate:
   SecLib.setup(withConfiguration: cfg, name: "AppA")
     → SecLib.setup(config: cfg, name: "AppA")                @core/SecLib/SecLib.swift:296
        ├ sessionIDManager.setup()                            (one-time; shared)
        ├ let core = CoreManager(configuration: cfg, …, appName: "AppA")
        ├ Instances["AppA"] = SecLib(core:, appName:)
        ├ for lib in components:                              (Analytics, Crashes, CustomerChannel, …)
        │    for configComponent in cfg.components where configComponent[lib.name] != nil:
        │       lib.configure(with: configComponent, core: core)
        │           → Analytics.configure → SecLib.configure(with:core:)   @ana/Managers/SecLib+Analytics.swift:26
        │             → build CoreAnalyticsManager, store in SecLib.analyticsManagers["AppA"]
        └ core.startCoreLogic(completion: nil)                (fetches HomeDoc + settings, posts didReceiveSettingsNotification)
```

## Config side — how a module's config reaches `configure(...)`

```swift
// App code
let cfg = Configuration.Builder()
    .setEnvironment(.GCPPRE)
    .setPackageName("com.market.app")
    .addConfiguration(AnalyticsConfiguration(networkMonitor: true))           // Configurable, key = "analytics"
    .addConfiguration(CrashReportConfiguration(enabled: true, …))              // Configurable, key = "crashes"    (when Crashes SDK is imported)
    .addConfiguration(CustomerChannelConfiguration(…))                         // Configurable, key = "channel"    (when CustomerChannel SDK is imported)
    .build()

// Under the hood
Builder.addConfiguration(_:)              @core/Models/Configuration.swift:98
  → dedupe by key
  → append configuration.build() (i.e. [key: [String: Any]]) to Configuration.components
```

- Each entry in `Configuration.components` is a single-key dict shaped `["analytics": [ … ]]`.
- At setup, the fan-out loop matches `configComponent[lib.name] != nil` — that's the `name` ↔ `key` handshake. Mismatch = the module is loaded but silently uninitialized.
- If a module is **linked but no config is added**, its `configure(...)` never runs. That's why `AnalyticsConfiguration` must be added to the builder even if all its flags are defaults.

## Multi-instance behavior

Every `SecLib.setup(...)` call re-runs the fan-out for a fresh `appName`. So each module's `configure(with:core:)` is called **once per instance**. Analytics keeps that per-instance state in `SecLib.analyticsManagers[appName]` (`@ana/Managers/SecLib+Analytics.swift:15,48`). See [../MultiInstance/copilot-multi-instance.md](../MultiInstance/copilot-multi-instance.md).

## Where to look when debugging

| Symptom | Check |
| --- | --- |
| Console shows `SecLib: <Module> Loaded` but nothing happens | Config key mismatch — the app didn't `addConfiguration(<ModuleConfiguration>)`, or its `key` doesn't equal the module's `SecLibrary.name`. Grep both sides for the exact string. |
| No `SecLib: <Module> Loaded` log at all | `+load` didn't fire — obj-c linker didn't pull in the loader class. Add `-ObjC` to Other Linker Flags, or `-force_load` on the framework. |
| `SecLib.configure(with: configuration, core:)` never called | Same as above — either module wasn't registered (`registerComponent` not called in `startLogic`) or config not added by app. |
| Duplicate registrations | `registerComponent` is append-only; make sure `+load` runs once (obj-c guarantees this per class). If two loaders share the same `SecLibrary`, refactor. |
| Feature works on `"Default"` instance, not on named one | Config was added on `Builder` but `SecLib.setup(withConfiguration:, name: "X")` used a different builder. Verify one `Configuration` per instance. |
| Analytics is silent even though `SecLib` was set up | `configComponent["analytics"] == nil` — the app forgot `.addConfiguration(AnalyticsConfiguration(...))`. Also happens if a stale JSON config lacks the `"analytics"` key. |

## Enhancing — adding a NEW SDK module (e.g. `Crashes`, `Rating`, …)

Follow this checklist to plug a new module into `SecLib`:

1. **Loader** (obj-c) under `<YourModule>/SecLibLoader/<YourModule>SecLibLoader.m`:
   ```objc
   #import <YourModule/YourModule-Swift.h>
   @implementation YourModuleSecLibLoader
   + (void)load {
       NSLog(@"SecLib: YourModule Loaded");
       [[[YourModule alloc] init] startLogic];
   }
   @end
   ```
2. **Bootstrap class** conforming to `SecLibrary` under `<YourModule>/Managers/YourModule.swift`:
   ```swift
   public class YourModule: NSObject, SecLibrary {
       public var name: String = YourModuleConfigKeys.yourModule   // e.g. "yourModule"
       public func configure(with configuration: [String: Any], core: CoreManagerProtocol) {
           // build per-instance state, store in a static dict keyed by core.appName
       }
       @objc public func startLogic() {
           SecLib.registerComponent(self)
       }
   }
   ```
3. **Config type** conforming to `Configurable`:
   ```swift
   public class YourModuleConfiguration: Configurable {
       public var key: String = YourModuleConfigKeys.yourModule    // same string as SecLibrary.name
       // … your fields (with defaults)
       // Codable if it must decode from JSON (smapi-config.json path)
   }
   ```
4. **Config key** — one place, exported: `enum YourModuleConfigKeys { static let yourModule = "yourModule" }` under `<YourModule>/Utilities/Constants.swift`.
5. **State container** — mirror Analytics: static registry on `SecLib` extension, keyed by `appName`. Example:
   ```swift
   public extension SecLib {
       internal static var yourModuleManagers: [String: YourModuleManager] = [:]
       static func configure(with configuration: [String: Any], core: CoreManagerProtocol) {
           let mgr = YourModuleManager(…, core: core)
           SecLib.yourModuleManagers[core.appName] = mgr
       }
   }
   ```
6. **Public API surface** — add methods to `SecLib` in a `SecLib+YourModule.swift` extension, forwarding via `SecLib.yourModuleManagers[appName]?.…` (same pattern as `SecLib+Analytics.getAnalytics()` @ `@ana/Managers/SecLib+Analytics.swift:51`).
7. **Multi-instance contract** — respect [../MultiInstance/copilot-multi-instance.md](../MultiInstance/copilot-multi-instance.md): state on the per-instance manager (not on `YourModule` itself, which is shared), notifications suffixed `-\(appName)`, use per-instance `UserDefaults(suiteName: "SecLibUserDefaults-\(appName)")`, add `appName` to any predicate.
8. **Do NOT touch Core's swizzling** — that's `Core`'s only responsibility. Modules consume the notifications it emits.
9. **Documentation** — add a feature doc under `.github/features/<YourModule>/` and a row in the master `.github/copilot-instructions.md` §3.

## Related
- Multi-instance rules the module must follow: [../MultiInstance/copilot-multi-instance.md](../MultiInstance/copilot-multi-instance.md)
- Analytics' concrete implementation of every step above: [../AnalyticsManager/copilot-setup-logEvent.md](../AnalyticsManager/copilot-setup-logEvent.md) and `@ana/Managers/SecLib+Analytics.swift`
- Swizzling installation (Core's exclusive job): [../AutoInstrumentation/copilot-auto-instrumentation.md](../AutoInstrumentation/copilot-auto-instrumentation.md)
- Setup flow inside `CoreManager`: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md)
