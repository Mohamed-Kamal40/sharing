# Enable / Disable Analytics

Toggle analytics collection at runtime. **Default: enabled.**

## Public API (entry point)
- **File:** `SecLibAnalytics/Managers/SecLib+Analytics.swift:231`
- **Signature:** `@objc var enableAnalytics: Bool` (get/set on `SecLib`)
- **Module:** declared as an extension of `SecLib` — the class lives in `@core`, this property is added by `@ana`.

## Call graph
```
SecLib.enableAnalytics {get/set}                           @ana/Managers/SecLib+Analytics.swift:231
  → getAnalytics()?.enabled                                @ana/Managers/SecLib+Analytics.swift:52  (private helper)
    → CoreAnalyticsManager.enabled                         @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift
      → checked at top of logEvent(_:)                     @ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:56
      (`guard enabled && coreManager.smapiEnable else { return }`)
```

## Where to look when debugging
| Symptom                                    | Check                                                                 |
| ------------------------------------------ | --------------------------------------------------------------------- |
| Events still fire after disable            | `CoreAnalyticsManager+Extension.swift:56` early-return; verify `enabled` mutated on the right instance |
| `enableAnalytics` toggle has no effect     | `getAnalytics()` returning `nil` → instance name mismatch (`SecLib.analyticsManagers[appName]`) |
| Multiple `SecLib` instances behave differently | Each instance has its own `CoreAnalyticsManager` — the toggle is per-`appName` |

## Enhancing
- To add a persisted-off state, wire a UserDefaults read in `@ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift` `enabled` init, following the shape of `UserDefaults+Values.swift` (both `@core` and `@ana` have one).
- Do not gate `SecLib`'s own `enabled` (`@core/SecLib/SecLib.swift:32`) — that flag disables **all** SecLib components (Analytics + Crashes + CustomerChannel), not just analytics.

## Setup / Configuration

Initial value comes from `AnalyticsConfiguration.enabled` (default **`true`**), decoded from `analytics.enabled` in `smapi-config.json`. The runtime property `SecLib.enableAnalytics` overrides it thereafter.

**Builder:**
```swift
let cfg = Configuration.Builder()
    .setPackageName("<pkg>")
    .addConfiguration(AnalyticsConfiguration(enabled: true))
    .build()
```

**JSON (`smapi-config.json`):**
```json
"analytics": { "enabled": true }
```

- Full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md)
- How `AnalyticsConfiguration` is fanned out into `CoreAnalyticsManager` at setup: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md)

## Related
- Full-SDK master switch: `SecLib.enabled` at `@core/SecLib/SecLib.swift:32` (different from `enableAnalytics` — that disables **all** SecLib components, not just Analytics).
