# SwiftUI Item Tracking (`.secLibTrackedItem()`)

Modifier that logs SwiftUI `Button` presses via the same event pipeline as UIKit `UIControl` events.

## Public API (entry point)
- **File:** `CoreSDK/SecLibCore/Analytics/Extensions/SwiftUI/ButtonGestureModifier.swift:50`
- **Signature:** `public func secLibTrackedItem() -> some View` on `Button`
- **Module:** `@core.ana` — SwiftUI tracking is Core-side analytics code (in `@core/Analytics/`).

## Call graph
```
Button.secLibTrackedItem()                    @core/Analytics/Extensions/SwiftUI/ButtonGestureModifier.swift:50
  → applies ButtonGestureModifier             @core/Analytics/Extensions/SwiftUI/ButtonGestureModifier.swift:12 (approx)
    → onTap / onLongPress → logTrackedItem() @core/Analytics/Extensions/SwiftUI/ButtonGestureModifier.swift:33
      → EventData(type: .controls, element: EventElementNames.swiftUIButton, ...)
      → UIApplication.eventNotificationCenter?.post(
          name: Notifications.interactionEvent,        (@core/CoreUtility/Constants.swift:41 enum)
          userInfo: [Notifications.interactionEvent: EventData]
        )
```

The `interactionEvent` notification is consumed downstream by `CoreAnalyticsManager` observers in `@ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:273 addEventObservers()`.

## Where to look when debugging
| Symptom                                    | Check                                                                     |
| ------------------------------------------ | ------------------------------------------------------------------------- |
| Modifier compiles but no event fires       | `UIApplication.eventNotificationCenter` is `nil` — Analytics setup didn't run before the button was tapped |
| Long-press not tracked                     | Verify both tap + long-press paths in `ButtonGestureModifier` |
| Event fires but `event-element` wrong      | `EventElementNames.swiftUIButton` is a constant — change it in `EventConstants.swift` (`@core/Analytics/Utilities/Enums/EventConstants.swift`) |
| Non-`Button` views want tracking           | Modifier is defined only on `Button`; extend `View` (or specific type) with a new function, still calling `logTrackedItem()` |

## Enhancing
- To capture the button's label into `description`, read it via `PreferenceKey` or a `ButtonStyle` wrapper and pass it into `EventData(description:)` at `ButtonGestureModifier.swift:38`.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- UIKit auto-capture equivalents: `@core/Analytics/Extensions/UIControl/` (`UIButton+`, `UISwitch+`, `UISegmentedControl+`, …)
- Notification observers on the analytics side: `@ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:273`.
