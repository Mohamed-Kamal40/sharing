# Auto-Instrumentation (Swizzling → Event)

Every automatic capture (UIControl, TableView/CollectionView, screen load time, screen stay time, network) rides the **same bootstrap and event pipeline**. Read this doc when a bug spans more than one auto-captured feature.

## 1. Bootstrap — one entry point

```
CoreSecLibLoader (+load)                         @core/SecLib/CoreSecLibLoader.m:15
  → Core().startLogic()                           @core/Managers/Core.swift:14
    → enableSwizzling()                           @core/Managers/Core.swift:18   ← ALL swizzles installed here
        UIViewController.swizzleLifeCycleMethods            (screen load / stay time, screen name)
        URLSession.trackAllDataTask                          (network monitor)
        UITableView.swizzleTableView                         (row selection)
        UICollectionView.swizzleCollectionView               (item selection)
        UIApplication.setNotificationsForLifecycleEvents     (app lifecycle → sessionID validity, etc.)
        UIApplication.uiControlActionSwizzleMethod           (sendAction targets)
        UIApplication.uiControlEventSwizzleMethod            (sendEvent → gesture-driven controls)
        UIScene.setNotificationsForUISceneLifecycleEvents    (iOS 13+ scene lifecycle)
```

`+load` runs before `main()`, so swizzles are in place before the app starts making any calls.

## 2. Setup / Configuration gate

Method swizzling itself is installed **unconditionally** at `+load` — no config knob gates it. What IS config-gated is the **analytics-side observer** for the `interactionEvent` broadcast (from UIControl, TableView, CollectionView, SwiftUI, screen load/stay time). That observer registers only when `AnalyticsConfiguration.viewLifeCycleTrackedEnabled == true` (default **`true`**) — see `CoreAnalyticsManager.addEventObservers()` @ `@ana/…/CoreAnalyticsManager.swift:281`.

**Builder:**
```swift
Configuration.Builder()
    .addConfiguration(AnalyticsConfiguration(viewLifeCycleTrackedEnabled: true))  // default true
    .build()
```

**JSON (`smapi-config.json`):**
```json
"analytics": { "viewLifeCycleTrackedEnabled": true }
```

- Setting `false` stops interaction events reaching Analytics AND stops `ViewControllerCalculator` (`ViewContollerCalculation.swift:50 stop()`) — so screen load/stay time are also disabled. Intended for embedding contexts (e.g. React Native) that emit their own events.
- Network events use a separate config (`networkMonitor`) and observer path — not gated by this flag.
- Full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Config handshake: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).

## 3. Common event pipeline

Every auto-capture posts a `NotificationCenter` event that lands in `CoreAnalyticsManager` and funnels through `logEvent(_:)`:

```
<swizzle> → EventData → NotificationCenter.post(name: Notifications.interactionEvent | networkEvent | networkEventData-<appName>)
  → CoreAnalyticsManager observer                @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:273 addEventObservers()
    → receiveEventsMessage(_:)                   @ana/…/CoreAnalyticsManager.swift:344   (interaction)
    → handleNetworkEvent(_:)                     @ana/…/CoreAnalyticsManager.swift:168   (network)
      → logEvent(_ eventData:)                   @ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:56
        (guard enabled/smapiEnable → PII mask → createEvent → block-list check → CoreData → flush)
```

Notification names: `enum Notifications` at `@core/CoreUtility/Constants.swift:41`. See [../EventStorage/copilot-event-storage.md](../EventStorage/copilot-event-storage.md) for what happens after `logEvent(_:)`.

## 4. Per-feature capture

### 3.1 UIControl (`sendAction` — Buttons, Switches, Steppers, Segmented, etc.)
```
UIApplication.sendAction(_:to:from:for:)  ← swizzled
  → interceptAction(_:to:from:for:)                 @core/Analytics/Extensions/UIApplication/UIApplication+UIControlActionSwizzling.swift:30
    → captureSenderInfo(sender:action:)              (line 42)
      → logTrackedItem(sender:action:)               (line 47)
        → EventData(type: .controls, element: sender.element, description: action)
        → post Notifications.interactionEvent        → observer at CoreAnalyticsManager.swift:262
```
Elements are tagged via the `UITrackedItem` protocol; conforming types under `@core/Analytics/Extensions/UIControl/` (`UIButton+UITrackedItem.swift`, `UISwitch+UITrackedItem.swift`, …).

### 3.2 UIControl (`sendEvent` — gesture-driven controls: sliders, pickers, alerts, images)
```
UIApplication.sendEvent(_:)   ← swizzled
  → interceptEvent(_:)                              @core/…/UIApplication+UIControlEventSwizzling.swift:31
    → UIControlEvent.captureGestureEvents(for:)     @core/Analytics/Managers/UIControlEvent.swift:26
      → per-touch phase handlers (began / ended)    → posts Notifications.interactionEvent
```

### 3.3 UITableView / UICollectionView (row/item selection)
```
UITableView.delegate = X   ← swizzled setter
  → swizzledTableViewDelegate(delegate:)            @core/Analytics/Extensions/UIControl/TableView+Swizzling.swift:22 / CollectionView+Swizzling.swift:22
    → per-delegate swizzle of tableView(_:didSelectRowAt:) / collectionView(_:didSelectItemAt:)
    → customTableView(_:didSelectRowAt:) / customCollectionView(_:didSelectItemAt:)
      → EventData(type: .controls, element: EventElementNames.uiTableView | uiCollectionView, description: indexPath)
      → post Notifications.interactionEvent
```
Two-level swizzling: (a) UITableView's `delegate` setter is swizzled once, (b) each concrete delegate class is swizzled the first time it's assigned (see `SwizzleHelper.beginSwizzling(owningClass:key:)`).

### 3.4 UIViewController lifecycle (screen navigation + load time + stay time)
```
UIViewController.viewDidLoad / viewDidAppear / viewWillDisappear   ← swizzled
  → custom<Lifecycle> methods                       @core/Extensions/UIViewController/UIViewController+Swizzling.swift:112,127,135
    → post ViewControllerLifeCycle.<name> notifications (userInfo carries the VC + optional EventData)

ViewControllerCalculator (observer)                 @ana/Managers/ViewContollerCalculation.swift:14
  ├ viewDidLoad(_:)   line 72  → viewStartTime = Date()
  ├ viewDidAppear(_:) line 83  → build ViewControllerInfo, push onto viewControllers stack
  │                            → logLoadTime → checkAndLogPageLoadTime  line 168
  │                              → EventData(type: .page, element: EventElementNames.pageLoadTime,
  │                                          description: "<sec> sec", page: currentPageName)
  │                              → post Notifications.interactionEvent
  └ viewWillDisappear(_:) line 105 → saveAndLogStayTime  line 187
                                    → EventData(type: .page, element: EventElementNames.userStayTime,
                                                description: "<sec> sec", page: currentPageName,
                                                hangDuration: getHangDuration(identifier:))
                                    → post Notifications.interactionEvent
```
- **Load time** = `viewDidAppear.time - viewDidLoad.time` (per VC instance identity via `ObjectIdentifier`).
- **Stay time** = `viewWillDisappear.time - viewDidAppear.time` (same VC identity).
- Both events land under `event-type: Page`.
- `hang-duration` is stitched in from `UIViewControllerHangMonitor` — see [../UIHangs/copilot-ui-hangs.md](../UIHangs/copilot-ui-hangs.md).
- Certain system VCs are skipped in `pageNameCheck(pageName:)` (`ViewContollerCalculation.swift:151`) — keyboard/input helpers.

### 3.5 Network (URLSession)
Full 5-stage pipeline documented separately: [../NetworkMonitor/copilot-network-monitor.md](../NetworkMonitor/copilot-network-monitor.md).

## 5. Where to look when debugging (any auto-capture)

| Symptom | Check |
| --- | --- |
| Nothing auto-captured at all | `+load` didn't run (obj-c linker `-ObjC` / force_load flag on framework). Console log `SecLib: Core Loaded` at `CoreSecLibLoader.m:14`. |
| One feature's swizzle silent | Only the corresponding call inside `Core.enableSwizzling()` was skipped — every swizzle guards on a `swizzled` flag; if the class was subclassed and swizzled once, it stays that way. |
| Interaction events not persisted | `analyticsConfiguration.viewLifeCycleTrackedEnabled == false` disables the `interactionEvent` observer (`CoreAnalyticsManager.swift:281`). |
| Custom subclass of UITableViewDelegate not tracked | `SwizzleHelper.isSwizzlableClass` rejected it — check `@core/Analytics/Utilities/SwizzleHelper.swift`. |
| Load time = 0 | `viewDidLoad` didn't run before `viewDidAppear` (rare — view materialized synchronously). Check `viewController.didLoad` flag in `ViewContollerCalculation.swift:127`. |
| Stay time missing on background | `viewWillDisappear` is skipped by iOS during backgrounding — background events are handled separately by `UIApplication` lifecycle observer, not by `ViewControllerCalculator`. |
| Screen name is class name, not custom | Called `setScreenName` too late — see [../ScreenName/copilot-screen-name.md](../ScreenName/copilot-screen-name.md). |
| Duplicate events for one tap | Both `sendAction` and `sendEvent` swizzles fired (custom control routes touches through both). Deduplicate at the source, not in the observer. |

## 6. Enhancing (patterns to reuse)

- **New swizzle**: add a call to `Core.enableSwizzling()` in Core.swift:18, put the extension file under `@core/Analytics/Extensions/…/`, guard on a private `swizzled` flag, use `SwizzleHelper` for per-instance-class swizzling.
- **New EventData source**: post to `Notifications.interactionEvent` with a `[Notifications.interactionEvent: EventData]` userInfo — observer in `@ana` already handles it.
- **New event category** (beyond `.controls`, `.page`, `.custom`, `.network`, `.application`): extend `EventCategory` in `@core/Analytics/Utilities/Enums/EventConstants.swift`.

## 7. Test locations

- `@tests.core/Analytics/URLSessionTaskExtensionTests(+Delegate).swift`, `NetworkTrackingManagerTests.swift`, `TrackedDataTaskTests.swift`
- `@tests.core/Analytics/UIControlEventTests.swift`, `UIApplicationSwizzleTests.swift`, `UISceneSwizzleTests.swift`
- `@tests.core/Analytics/UITableViewSwizzleTests.swift`, `UICollectionViewSwizzleTests.swift`
- `@tests.core/Analytics/UIViewControllerTests.swift`, `UIViewTests.swift`
- `@tests.core/Analytics/ButtonGestureModifierTests.swift` (SwiftUI)

## Related
Sources funnel here: [../NetworkMonitor/](../NetworkMonitor/copilot-network-monitor.md) · [../SwiftUITracking/](../SwiftUITracking/copilot-swiftui-tracking.md) · [../ScreenName/](../ScreenName/copilot-screen-name.md) · [../UIHangs/](../UIHangs/copilot-ui-hangs.md)  
Downstream: [../AnalyticsManager/](../AnalyticsManager/copilot-setup-logEvent.md) · [../EventStorage/](../EventStorage/copilot-event-storage.md)
