# Transfer Session ID (Native → Web)

Append `smapi_session_id`, `smapi_install_id`, `smapi_subject_id` as query params so a WebView continues the native session.

## Public API (entry point)
- **File:** `SecLibAnalytics/Managers/SecLib+Analytics.swift:134`
- **Signature:** `@objc func appendSession(for url: URL) -> URL?`
- **Return type:** `URL?` (nil if the URL cannot be rebuilt).

## Call graph
```
SecLib.appendSession(for:)                       @ana/Managers/SecLib+Analytics.swift:134
  → CoreAnalyticsManager.appendSession(for:)     @ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:14
    → parameters:
        smapi_session_id = SecLib.getSessionID()          (calls @core session manager)
        smapi_install_id = UtilityManager.getInstallID()  (from @util)
        smapi_subject_id = UtilityManager.getUUID()       (from @util)
    → getUrlWithSMAPIParams(url:parameters:)     @ana/…/CoreAnalyticsManager+Extension.swift:22
      → preserves existing query and fragment
      → returns URL (or original on failure)
```

## Where to look when debugging
| Symptom                                    | Check                                                                    |
| ------------------------------------------ | ------------------------------------------------------------------------ |
| Returns `nil`                              | `getAnalytics()` returned `nil` — instance name mismatch                 |
| Existing query params dropped              | Handled at `CoreAnalyticsManager+Extension.swift:27-31` — check that block if changing query logic |
| Fragment (`#…`) lost                       | Preserved at `CoreAnalyticsManager+Extension.swift:34-36`                |
| Session ID changes mid-flow                | Native session may have rotated (5-min inactivity, `@core/Managers/SessionIDManager.swift:98`); re-call `appendSession` right before load |

## Enhancing
- Any new SMAPI-scoped query key belongs in the `parameters` dict at `CoreAnalyticsManager+Extension.swift:15-19` — mirror the naming convention `smapi_<name>`.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Underlying session state: [../SessionID/copilot-session-id.md](../SessionID/copilot-session-id.md)
