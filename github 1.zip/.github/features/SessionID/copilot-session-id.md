# Session ID

Read the current session ID and observe changes. Pure `@core` feature (no Analytics dependency).

## Public API (entry points)
| API                                    | File / Line                                                     |
| -------------------------------------- | --------------------------------------------------------------- |
| `getCurrentSessionID() -> String`      | `CoreSDK/SecLibCore/SecLib/SecLib.swift:175`                    |
| `subscribeToSessionID(_ cb:)`          | `CoreSDK/SecLibCore/SecLib/SecLib.swift:181`                    |
| Backing manager                        | `CoreSDK/SecLibCore/Managers/SessionIDManager.swift:18`         |
| Protocol                               | `CoreSDK/SecLibCore/Managers/SessionIDManager.swift:12` (`SessionIDManaging`) |
| Static instance on `SecLib`            | `CoreSDK/SecLibCore/SecLib/SecLib.swift:20` (`private static var sessionIDManager: SessionIDManaging = SessionIDManager()`) |

## Session lifecycle
- `SessionIDManager.setup()` (`SessionIDManager.swift:46`) installs two `NotificationCenter` observers:
  - `UIApplication.didEnterBackgroundNotification` → stores `didEnterBackgroundDate` in `UserDefaults` (suite `Constants.SessionIDUserDefaults`).
  - `UIApplication.didBecomeActiveNotification` → checks `isValidSession(...)` (`SessionIDManager.swift:92`); if backgrounded ≥ 5 minutes → `resetSessionID()` (`SessionIDManager.swift:78`) generates a new UUID and re-invokes callback.
- `sessionID` is a lazy UUID (`SessionIDManager.swift:36`); first read materializes it and fires the subscribed callback with it.

## Call graph
```
SecLib.getCurrentSessionID()               @core/SecLib/SecLib.swift:175
  → SessionIDManager.getSessionID()        @core/Managers/SessionIDManager.swift:82

SecLib.subscribeToSessionID(_:)            @core/SecLib/SecLib.swift:181
  → SessionIDManager.subscribeToSessionID  @core/Managers/SessionIDManager.swift:85
    → callback = closure
    → callback(sessionID)   // fires immediately with current value
```

## Where to look when debugging
| Symptom                                   | Check                                                                        |
| ----------------------------------------- | ---------------------------------------------------------------------------- |
| Callback never fires                      | Session ID hasn't changed; call `getCurrentSessionID()` first if you need the initial value logged |
| Session ID changes too often              | 5-min inactivity threshold at `SessionIDManager.swift:98` — tune there       |
| Two subscribers get lost                  | `SessionIDManager` holds a **single** `callback` — later subscribers overwrite earlier ones. Fix by converting `callback` to `[UUID: (String) -> Void]` |
| Session ID missing in URLs to WebView     | Use [../TransferSessionID/copilot-transfer-session-id.md](../TransferSessionID/copilot-transfer-session-id.md) |

## Enhancing
- The single-subscriber limitation (`callback: ((String) -> Void)?` at `SessionIDManager.swift:34`) is a common footgun. Convert to a dict keyed by token, return an unsubscribe closure from `subscribeToSessionID`.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Session-timeout constant: `Constants.SessionIDUserDefaults` at `@core/CoreUtility/Constants.swift`.
