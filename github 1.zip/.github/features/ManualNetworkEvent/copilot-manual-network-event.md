# Manual Network Event Logging

Log a network request/response pair explicitly. Reuses the same trace-ID capture, PII masking, and blacklist as auto-captured events.

## Public API (entry point)
- **File:** `SecLibAnalytics/Managers/SecLib+Analytics.swift:165`
- **Signature:** `@objc func requestMetrics(withURL url: String, method: HTTPMethod = .unknown, requestHeaders: [String: String]? = nil) -> SLRequestMetrics?`
- **Response call:** `SLRequestMetrics.logResponse(statusCode:responseHeaders:errorDescription:)`

## Types & handlers
| Symbol                            | Location                                                        |
| --------------------------------- | --------------------------------------------------------------- |
| `SLRequestMetrics` (public class) | `@ana/Model/SLRequestMetrics.swift:12`                          |
| Protocol contract                 | `@ana/Managers/AnalyticsManager/AnlyticsManagerProtocol.swift:30` |
| Handler impl                      | `@ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:194` (`func requestMetrics(...) -> SLRequestMetrics?`) |
| Constructor line                  | `CoreAnalyticsManager.swift:195` (`let metrics = SLRequestMetrics(...)`) |

## Call graph
```
SecLib.requestMetrics(withURL:method:requestHeaders:)   @ana/Managers/SecLib+Analytics.swift:165
  → CoreAnalyticsManager.requestMetrics(...)            @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:194
    → SLRequestMetrics(...)                             @ana/Model/SLRequestMetrics.swift:12
      → metrics.logResponse(...) — caller invokes on returned instance
```

## Where to look when debugging
| Symptom                              | Check                                                                |
| ------------------------------------ | -------------------------------------------------------------------- |
| `requestMetrics(...)` returns `nil`  | `getAnalytics()` returned `nil` — instance name mismatch (`SecLib.analyticsManagers[appName]`) or Analytics module not configured (`@ana/Managers/SecLib+Analytics.swift:26 configure(...)`) |
| Double-captured requests             | Network monitor still ON — call `setConfigureNetworkMonitoring(isConfigured: false)` first (`@ana/Managers/SecLib+Analytics.swift:104`). |
| Trace ID missing from resulting event| Header key mismatch — see [../TraceIDKey/copilot-trace-id-key.md](../TraceIDKey/copilot-trace-id-key.md) |
| Event never reaches DB               | Check `logEvent(_:)` early-return at `@ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:56` (`enabled && coreManager.smapiEnable`) |

## Enhancing
- Any additional fields to record on the response should be added to `SLRequestMetrics` (`@ana/Model/SLRequestMetrics.swift`) and mirrored in the event-description builder in `@core/Analytics/Models/TrackedDataTask.swift:101`.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Auto capture: [../NetworkMonitor/copilot-network-monitor.md](../NetworkMonitor/copilot-network-monitor.md)
- Header/body capture: [../NetworkRequestDetails/copilot-network-request-details.md](../NetworkRequestDetails/copilot-network-request-details.md)
