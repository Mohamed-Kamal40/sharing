# Log Components (Name + Version)

Report internal component names/versions once at startup as a custom event. Requires backend alignment (the custom event type must be registered on the DB side).

## Public API (entry point)
- **File:** `SecLibAnalytics/Managers/SecLib+Analytics.swift:179`
- **Signature:** `@objc func logComponents(_ components: [String: String]) -> Bool`

## Call graph
```
SecLib.logComponents(_:)                  @ana/Managers/SecLib+Analytics.swift:179
  → CoreAnalyticsManager.logComponents    @ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:43
    ├ guard !components.isEmpty else return false
    ├ JSONSerialization.data(withJSONObject: components) — else return false
    ├ let decoded = String(data:, encoding: .utf8)      — else return false
    ├ let eventData = EventData(type: .custom, element: "Component", description: decoded)
    └ self.logEvent(eventData)             @ana/…/CoreAnalyticsManager+Extension.swift:56
```

## Return value
- `true` = event queued.
- `false` = empty dict, JSON serialization failed, or UTF-8 decode failed.

## Event shape (as emitted)
```json
{
  "event-type": "UICustom",
  "event-element": "Component",
  "event-description": "{\"Splash\":\"7.0\", ... }"
}
```
(Description is the raw JSON string of the components dict; the backend must parse it.)

## Where to look when debugging
| Symptom                                     | Check                                                                     |
| ------------------------------------------- | ------------------------------------------------------------------------- |
| Always returns `false`                      | Dict empty, or contains non-JSON-serializable values (all values must be `String`) |
| Event never persisted                       | `logEvent(_:)` early-return at `CoreAnalyticsManager+Extension.swift:56` (`enabled && coreManager.smapiEnable`) |
| Backend rejects event                       | Component custom event not registered — coordinate with backend team      |
| Called multiple times per app run           | No dedup — every call emits a new event. If you need once-per-run semantics, guard on the app side. |

## Enhancing
- To emit as `.application` type instead of `.custom`, edit the `EventData(type: ...)` line at `CoreAnalyticsManager+Extension.swift:47`.
- To auto-detect module versions from `Bundle`, add a helper in `@util/Managers/UtilityManager.swift` and call it before `logComponents(_:)`.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Custom event path: [../LogCustomEvent/copilot-log-custom-event.md](../LogCustomEvent/copilot-log-custom-event.md)
