flowchart TD
%% --- Core SDK ---
subgraph Core_SDK[Core SDK]
    A[App Launch] --> B[SecLibCore +load]
    B --> C[Core.startLogic()]
    C --> D[enableSwizzling()]
    D --> E[Swizzle URLSession Tasks]
    E --> F[Intercept Network Call]
    F --> G[Create TrackedDataTask]
    G --> H[Post Notifications.networkEvent]
end

%% --- Analytics SDK ---
subgraph Analytics_SDK[Analytics SDK]
    H --> I[SecLibAnalytics Observes Event]
    I --> J[CoreAnalyticsManager.handleNetworkEvent]
    J --> K[logEvent(eventData)]
    K --> L[Apply PII Masking]
    L --> M[Create Event]
    M --> N[Log to Console]
    N --> O[Add Event to Queue]
    O --> P[Persist Event (coreStorageManager)]
    P --> Q[Schedule Flush (eventHandler)]
    Q --> R[Flush Events to Backend]
end
