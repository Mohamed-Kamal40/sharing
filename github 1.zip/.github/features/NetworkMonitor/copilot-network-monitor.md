# Network Monitor

Auto-capture outbound `URLSession` requests → `TrackedDataTask` → forward to the event pipeline. **Capture in `@core`, observe+persist in `@ana`.**

## Public API
| API | File / Line |
| --- | --- |
| `setConfigureNetworkMonitoring(isConfigured:)` / `getConfigureNetworkMonitoring()` | `@ana/Managers/SecLib+Analytics.swift:104,114` |
| Config: `AnalyticsConfiguration.networkMonitor` (default `false`) | `@ana/Model/AnalyticsConfiguration.swift:20,33` |
| Runtime backing property | `CoreAnalyticsManager.configureNetworkMonitoring` @ `@ana/…/CoreAnalyticsManager.swift:47` (didSet toggles observer) |

## Setup / Configuration

Setup-time value (default **`false`** = off):
```swift
let cfg = Configuration.Builder()
    .addConfiguration(AnalyticsConfiguration(networkMonitor: true))
    .build()
```
```json
"analytics": { "networkMonitor": true }
```
Runtime toggle: `secLib.setConfigureNetworkMonitoring(isConfigured: true)`.

Full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Config handshake into `CoreAnalyticsManager`: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).

## 5-stage pipeline

```
1. Bootstrap (Core, +load)
   CoreSecLibLoader.m:15 → Core().startLogic()  @core/Managers/Core.swift:14
     → enableSwizzling()                        @core/Managers/Core.swift:18
       → URLSession swizzles (data/upload/download, delegate + completion)
         @core/Analytics/Extensions/URLSession/URLSession+Swizzling.swift(+Extension)

2. Per-request capture (Core)
   swizzled URLSession.<task>() → build TrackedDataTask         @core/Analytics/Models/TrackedDataTask.swift
     (strips Authorization; body only if Content-Type=application/json)
     → post Notifications.networkEvent    (userInfo = [Notifications.networkEvent: TrackedDataTask])
       (constants @core/CoreUtility/Constants.swift:41)

3. Filter + describe (Core)
   CoreManager.setupNetworkTrackingManager()   @core/Managers/CoreManager/CoreManager.swift:111
     → NetworkTrackingManager.startTracking()  @core/Analytics/Managers/NetworkTrackingManager.swift
   captureNetworkInfo → logRequest(with:):
     - reject if URL matches ignoredDomains | customIgnoredDomains | ignoredExtensions
     - per-URL obfuscation (obfuscatedRequests/Responses)
     - getTID(): parse requestHeaders JSON at tidKey
     - eventDesc = TrackedDataTask.generateEventDescription(trackRequestDetailsIsEnabled)  :101
     → post Notifications.networkEventData + "-" + appName
       userInfo: [networkEventData: EventData(type:.network,…,tid), trackedDataTask: TrackedDataTask]

4. Observe + persist (Analytics)
   CoreAnalyticsManager.setup() → configureNetworkMonitoring = analyticsConfiguration.networkMonitor
     (didSet @ana/…/CoreAnalyticsManager.swift:47 → enableNetworkTraking() | disableNetworkTraking())
   enableNetworkTraking()                       @ana/…/CoreAnalyticsManager.swift:158
     → addObserver(handleNetworkEvent(_:))      for Notifications.networkEventData + "-" + appName
   handleNetworkEvent(_:)                       @ana/…/CoreAnalyticsManager.swift:168
     → logEvent(_:)  (see AnalyticsManager doc)

5. Runtime toggle
   SecLib.setConfigureNetworkMonitoring(isConfigured:)  @ana/Managers/SecLib+Analytics.swift:104
     → CoreAnalyticsManager.configureNetworkMonitoring = isConfigured  (didSet re-runs step 4 wiring)
```

## Where to look when debugging
| Symptom | Check |
| --- | --- |
| No events at all | `+load` didn't fire — verify obj-c linker flags (`-ObjC` / force_load). Log `SecLib: Core Loaded` at `CoreSecLibLoader.m:14`. |
| Events posted, not persisted | `configureNetworkMonitoring == false` on that `appName`'s `CoreAnalyticsManager`. |
| Only some URLs captured | Filter hit in `logRequest(with:)` — inspect ignored lists. |
| Trace ID missing | Empty `tidKey` or header absent — [../TraceIDKey/copilot-trace-id-key.md](../TraceIDKey/copilot-trace-id-key.md). |
| Headers/bodies not in event | `trackRequestDetailsIsEnabled == false` — [../NetworkRequestDetails/copilot-network-request-details.md](../NetworkRequestDetails/copilot-network-request-details.md). |
| Same request captured twice | Manual `logResponse` used while monitor still on. |
| Multi-instance leakage | Notification names suffix `-<appName>` — a mismatch crosses instances. |

## Enhancing
- New swizzled selector → add to `URLSession+Swizzling(+Extension).swift`, same "build `TrackedDataTask` + post" pattern.
- Filter semantics → edit `logRequest(with:)` in `NetworkTrackingManager.swift`.
- New per-request field → extend `TrackedDataTask` + thread through `generateEventDescription` (`:101`).

## Tests
`@tests.core/Analytics/`: `URLSessionTaskExtensionTests(+Delegate).swift`, `NetworkTrackingManagerTests.swift`, `TrackedDataTaskTests.swift`.

## Related
Swizzle bootstrap shared with other auto features: [../AutoInstrumentation/](../AutoInstrumentation/copilot-auto-instrumentation.md)  
Persistence + flush after `logEvent`: [../EventStorage/](../EventStorage/copilot-event-storage.md)  
[copilot-network-monitor-flowchart.md](copilot-network-monitor-flowchart.md) · [../NetworkRequestDetails/](../NetworkRequestDetails/copilot-network-request-details.md) · [../IgnoredDomains/](../IgnoredDomains/copilot-ignored-domains.md) · [../ManualNetworkEvent/](../ManualNetworkEvent/copilot-manual-network-event.md) · [../AnalyticsManager/](../AnalyticsManager/copilot-setup-logEvent.md)
