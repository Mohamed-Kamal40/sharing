# Screen Name

Override the auto-detected view controller class name with a developer-friendly name for logs and dashboards.

## Public API (entry point)
- **File:** `CoreSDK/SecLibCore/SecLib/SecLib.swift:124`
- **Signature:** `@objc public func setScreenName(screenName: String)`
- **Module:** `@core` — this is a **pure Core API**, no Analytics dependency.

## Call graph
```
SecLib.setScreenName(screenName:)                  @core/SecLib/SecLib.swift:124
  → CoreManager.setScreenName(name:)               @core/Managers/CoreManager/CoreManager.swift:218
    → currentScreenName = name                     (stored on CoreManager)
    → currentViewController?.setScreenName(name:)  @core/Managers/CoreManager/CoreManager.swift:80
      → UIViewController.setScreenName(name:)      @core/Extensions/UIViewController/UIViewController+Swizzling.swift:43
        → currentPageName = name                   (associated object on UIViewController)
```

## SwiftUI path
The `View.setScreenName(_:)` modifier is defined **in the sample app** (`AnalyticsSampleApp/…/View+SecLibSetScreenName.swift`), not the SDK. It calls the same public API in an `onAppear` block. If a market app needs SwiftUI, they must copy that extension (per docx).

## Where to look when debugging
| Symptom                                        | Check                                                                    |
| ---------------------------------------------- | ------------------------------------------------------------------------ |
| `page-name` still class name in events         | `setScreenName` called after `viewDidLoad` — swizzling has already stamped the class name. Call it inside `viewDidLoad`. |
| Screen name leaks to next VC                   | `currentPageName` is per-VC (associated object) — check `UIViewController+Swizzling.swift:23-42` accessor pair |
| SwiftUI screen not updating                    | `.setScreenName` modifier not wrapping the top-level container view      |
| Screen name lost on backgrounding              | Associated object survives lifecycle, but a rebuilt VC loses it — reapply on `viewDidLoad` |

## Enhancing
- To auto-detect a title (e.g. `navigationItem.title`) as fallback, extend `customViewDidLoad` swizzle in `@core/Extensions/UIViewController/UIViewController+Swizzling.swift` and set `currentPageName` there when the developer hasn't already.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Auto-emitted `Stay Time` + `Page Load Time` per VC (both carry `page-name`): [../AutoInstrumentation/copilot-auto-instrumentation.md](../AutoInstrumentation/copilot-auto-instrumentation.md) §4.4.
- UI hangs enrichment of `Stay Time`: [../UIHangs/copilot-ui-hangs.md](../UIHangs/copilot-ui-hangs.md).
- SwiftUI item tracking: [../SwiftUITracking/copilot-swiftui-tracking.md](../SwiftUITracking/copilot-swiftui-tracking.md).
