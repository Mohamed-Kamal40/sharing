# App Hang Detection

Detect longer-lived unresponsiveness (default threshold **3.0 s**) with stack traces, reported as discrete hang incidents via `NotificationCenter`.

## Setup / Configuration

**Setup-time only** (no runtime toggle). Defaults: `enabled = false`, `threshold = 3.0` seconds.

**Builder:**
```swift
let cfg = Configuration.Builder()
    .setPackageName("<pkg>")
    .addConfiguration(
        AnalyticsConfiguration(
            appHang: AppHangConfiguration(enabled: true, threshold: 3.0)
        )
    )
    .build()
```

**JSON (`smapi-config.json`):**
```json
"analytics": {
  "app_hang": {
    "track_app_hangs": true,
    "threshold": 3.0
  }
}
```

- Type: `AppHangConfiguration(enabled: Bool = false, threshold: Double = 3.0)` @ `@ana/Model/AnalyticsConfiguration.swift:69`
- Nested inside `AnalyticsConfiguration.appHang` (default = fresh `AppHangConfiguration()`) @ `AnalyticsConfiguration.swift:23`
- JSON keys via `CodingKeys` @ `AnalyticsConfiguration.swift:82`: `enabled` ↔ `track_app_hangs`; `threshold` ↔ `threshold`.
- Full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Config handshake: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).

## Implementation
| Component                | File                                                                   |
| ------------------------ | ---------------------------------------------------------------------- |
| Hang monitor             | `@ana/Managers/HangManager/AppHangMonitor.swift:13`                    |
| Reporter delegate        | `@ana/Managers/HangManager/AppHangReporterDelegate.swift`              |
| Hang time calculator     | `@ana/Managers/HangManager/AppHangTimeCalculator.swift`                |
| Hang event model         | `@ana/Model/AppHangInfo.swift`                                         |
| Static instance          | `@ana/Managers/SecLib+Analytics.swift:18` (`static var appHangMonitor = AppHangMonitor()`) |
| Setup hook               | `CoreAnalyticsManager.setupAppHangMonitor()` — `@ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:243` (called from `setup()` at line 219) |

## Call graph
```
App startup → SecLib.setup → SecLib+Analytics.configure → CoreAnalyticsManager.setup
  → setupAppHangMonitor()                              @ana/…/CoreAnalyticsManager.swift:243

At runtime, AppHangMonitor:
  RepeatingTimerManager (0.25s, main queue)   captures stack trace continuously
  RepeatingTimerManager (0.25s, bg queue)     checks main queue responsiveness
    → if diff > threshold:
       post NotificationCenter event with keys:
         AnalyticsNotification.appHangTimeDiffKey       (Double)
         AnalyticsNotification.appHangTimeIntervalKey   (TimeInterval)
         AnalyticsNotification.appHangStackTraceKey     ([SLStackTrace])
         AnalyticsNotification.appHangEventObjKey       (AppHangEvent)
       See: @ana/Managers/HangManager/AppHangMonitor.swift:47
```

## Where to look when debugging
| Symptom                            | Check                                                                     |
| ---------------------------------- | ------------------------------------------------------------------------- |
| No hang events reported            | `AnalyticsConfiguration.appHang.enabled == true`? `setupAppHangMonitor()` wired? |
| Threshold ignored                  | `threshold` decoded from JSON at `AnalyticsConfiguration.swift:69`+ then read inside `AppHangMonitor` |
| Duplicate reports across instances | Static `AppHangMonitor` shared across instances (`SecLib+Analytics.swift:18`) — filter by `appName` if needed |
| Stack trace empty                  | `SLStackTrace().buildStackTrace(...)` failed — check `@util` `SLStackTrace` |

## Vs. UI Hangs
- **UI Hangs** (`[../UIHangs/copilot-ui-hangs.md](../UIHangs/copilot-ui-hangs.md)`) = micro-stalls ≥ 250 ms, aggregated per screen into `hang-duration`.
- **App Hang** = discrete incidents ≥ 3 s (configurable), each with stack trace.

## Enhancing
- Polling cadence is hardcoded 0.25 s in the two `RepeatingTimerManager` inits (`AppHangMonitor.swift:22-23`). To make it configurable, add a param and forward it in `setupAppHangMonitor()`.
