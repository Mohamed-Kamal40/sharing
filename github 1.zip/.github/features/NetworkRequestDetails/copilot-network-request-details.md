# Network Request Details Logging

Capture request/response headers and JSON bodies alongside each auto-captured network event, with PII masking. **Requires network monitor ON** ([../NetworkMonitor/copilot-network-monitor.md](../NetworkMonitor/copilot-network-monitor.md)).

## Setup / Configuration

**Setup-time only** (no runtime toggle — value is applied when `SecLib.setup(...)` builds `CoreAnalyticsManager`). Default **`false`**.

**Builder:**
```swift
let cfg = Configuration.Builder()
    .addConfiguration(AnalyticsConfiguration(networkMonitor: true, trackRequestDetails: true))
    .build()
```

**JSON (`smapi-config.json`):**
```json
"analytics": {
  "networkMonitor": true,
  "track_request_details": true
}
```

- Property: `AnalyticsConfiguration.trackRequestDetails` @ `@ana/Model/AnalyticsConfiguration.swift:22`
- JSON key: `track_request_details` — decoded at `AnalyticsConfiguration.swift:52,63`
- Builder init param: `AnalyticsConfiguration(trackRequestDetails: Bool = false, …)` @ `AnalyticsConfiguration.swift:36`
- Full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Config handshake into `CoreAnalyticsManager`: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).

## Runtime plumbing (in @core)
The setting is pushed from `@ana` into `@core`'s network capture:

```
CoreAnalyticsManager.setup()                                        @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:213
  → coreManager.setTrackRequestDetails(isEnabled: …)                 (delegate)
    → CoreManager+NetworkTrackingManagerProtocol.swift:30            @core/Managers/CoreManager/CoreManager+NetworkTrackingManagerProtocol.swift
      → NetworkTrackingManager.trackRequestDetailsIsEnabled          @core/Analytics/Managers/NetworkTrackingManager.swift:18
        → TrackedDataTask.generateEventDescription(_:)               @core/Analytics/Models/TrackedDataTask.swift:101 (adds keys)
```

## Where each field is built
- **File:** `@core/Analytics/Models/TrackedDataTask.swift:101` — `generateEventDescription(_ trackRequestDetailsIsEnabled: Bool)`.
  - Early-return path when disabled: line 119.
  - Field caps and JSON validity checks live in this function.

## Fields added to `event-description`
| Key               | When captured                                                   |
| ----------------- | --------------------------------------------------------------- |
| `requestHeaders`  | Always (dict `[String: String]`)                                |
| `responseHeaders` | Always (dict `[String: String]`)                                |
| `requestBody`     | Only if `Content-Type: application/json` and body is valid non-empty JSON |
| `responseBody`    | Same rule as `requestBody`                                      |

Each field is truncated at **500 characters** (see `TrackedDataTask.swift`).

## Where to look when debugging
| Symptom                              | Check                                                                |
| ------------------------------------ | -------------------------------------------------------------------- |
| Body missing from event              | Content-Type not `application/json`, empty body, or invalid JSON — see `TrackedDataTask.swift:101+` |
| Field longer than expected           | 500-char cap in `TrackedDataTask.swift`                              |
| Setting ignored                      | Verify `AnalyticsConfiguration.networkMonitor == true`; else skipped in `NetworkTrackingManager` |
| PII not masked                       | Masking applied in event-description pipeline (`DynamicPII.swift` in `@ana/Model/`) |

## Related
- Auto capture: [../NetworkMonitor/copilot-network-monitor.md](../NetworkMonitor/copilot-network-monitor.md)
- Manual variant: [../ManualNetworkEvent/copilot-manual-network-event.md](../ManualNetworkEvent/copilot-manual-network-event.md)
