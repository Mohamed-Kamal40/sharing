# Event Storage, Flush & PII Masking

Where events go after `logEvent(_:)`. **Every event on every SDK path lands here.**

## Layers
| Symbol | File / Line |
| --- | --- |
| Storage protocol | `PersistentDataManager` @ `@ana/Managers/CoreData/CoreDataManager.swift:14` |
| CoreData impl | `class CoreDataManager` @ `@ana/Managers/CoreData/CoreDataManager.swift:33` |
| Insert / evict / fetch / delete | `@ana/Managers/CoreData/CoreDataManager+Event.swift` |
| Flush controller | `class EventHandler` @ `@ana/Managers/EventHandler.swift:14` |
| Storage wrapper (called by `CoreAnalyticsManager`) | `AnalyticsStorageManager` @ `@ana/Managers/AnalyticsStorageManager.swift:43,86,113` |
| Runtime settings container (defaults + JSON decode) | `class AnalyticsSetting` @ `@ana/Model/AnalyticsSetting.swift` |
| PII regex model | `struct DynamicPII` @ `@ana/Model/DynamicPII.swift` |
| PII apply function | `applyPII(forEventDescription:type:)` @ `@ana/…/CoreAnalyticsManager+Extension.swift:121` |
| CoreData model / entity | `@ana/SecLibDB.xcdatamodeld` → `EventModel` (fields: `payload: Data?`, `timestamp`, `transactionID`, `appName`) |
| Payload codec | `Event.toData().encryptedData` / `payload?.decryptedData` (encrypted on disk) |

## Where these settings come from — HomeDoc → Settings → override defaults

**Every value in the table below can be overridden from the backend.** The constants in `AnalyticsSetting.swift` are only used when the backend response omits that key. The initial HomeDoc + Settings fetch is triggered as part of `SecLib.setup(...)` — full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md). Config handshake at setup: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).

```
Core.startCoreLogic → setupEnvironment                 @core/Managers/CoreManager/CoreManager.swift:190
  → startRequestEntryPoints(headers:)                   @core/…/CoreManager.swift:222
     1. network.fetchHomeDoc(with: settings.homeDocURLFor(environment:), headers:)
        → post Notifications.didReceiveHomeDocNotification-<appName>  (userInfo = HomeDoc dict)
     2. If HomeDoc has a settingsURL AND (no lastTimeSetup OR nextTimeSetup < now):
          network.fetchSettings(url:, headers:)         (~7-day refresh throttle @ CoreManager.swift:245)
            on success:
              storage.lastTimeSetup = Date().timeIntervalSince1970
              storage.resetSetting(newSettings: settingsDic)   (persisted, encrypted, in @core StorageManager)
            on failure → log "Cashed settings will be used"; keep prior on-disk copy.
  → post Notifications.didReceiveSettingsNotification   (userInfo = saved settings dict)

CoreAnalyticsManager.updateSettings(_:)                 @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:323
  → UtilityManager.mapSetting(type: AnalyticsSetting.self, settingDic:)   (JSON → AnalyticsSetting)
    → AnalyticsSetting.init(from decoder:)              @ana/Model/AnalyticsSetting.swift:32
        for each key: updateIfPresent(&<field>, forKey: <CodingKey>)   (line 47)
        ── missing key → default from the declaration is kept
        ── present key → default is overwritten
  → self.updateSetting(newSettings:)                    (rebuilds EventHandler with new setting)
```

There's also a **cold-start fast path**: `startCoreLogic` calls `settingsCheck()` (`@core/…/CoreManager.swift:267`) which posts `didReceiveSettingsNotification` with the **cached** settings immediately — so `AnalyticsSetting` gets populated from disk before the network fetch even returns. When the fresh fetch lands, `updateSettings(_:)` fires again with the newer values.

## Runtime settings — defaults & JSON keys

| Setting | Default (fallback) | JSON key in settings response | Meaning |
| --- | --- | --- | --- |
| `flushEventCount` | **10** | `flush_event_count` | Flush kicks in when DB count **≥** this. |
| `flushInterval` | **30** sec | `flush_interval_seconds` | Timer-driven flush cadence. |
| `maxEventsInDatabase` | **1000** | `max_events_in_database` | DB cap. Oldest events evicted to make room on insert. |
| `maxNumberOfEvents` | **3000** | `max_number_of_events` | Rolling send cap (`UserDefaults.totalEventsSent`). At 0 remaining → `flush()` stops. |
| `noEventsInFlush` | **50** | `no_events_in_flush` | Max events per flush batch. |
| `noUserIdEventAge` | **28** days | `no_user_id_event_age` | Events older than this are purged on `start()`. |
| `ignoreList` / `whitelist` | `nil` | `blacklist` / `whitelist` | Server-side blocking rules — checked by `eventBlockingCheck` @ `@ana/…/CoreAnalyticsManager+Extension.swift:184`. |
| `dynamicPII` | see PII section | `dynamicPII` | Regex-based masking config. |

> Common gotcha: **backend key ≠ Swift property name** for most of these. Look at the `enum CodingKeys` at `@ana/Model/AnalyticsSetting.swift:51`. If backend uses a different key name, the value silently falls back to the default.

## PII masking — regex, event-type filter, replacement

**Model** (`@ana/Model/DynamicPII.swift`):
```swift
struct DynamicPII: Codable {
    var regexPattern: [String]   // e.g. ["\\d{9}"]  — regex list, all applied in order
    var eventType: [String]      // e.g. ["Network"] — masking runs only for these event types
    var maskedString: String     // e.g. "MASKEDMSISDN" — replacement template
}
```

**Default** (used only if `dynamicPII` is missing from server settings):
- `regexPattern: ["\\d{9}"]` — matches any run of 9 consecutive digits (MSISDN-shaped).
- `eventType: ["Network"]` — masking applied only to `Network`-type events.
- `maskedString: "MASKEDMSISDN"` — matched substrings are replaced with this literal.

**Apply logic** (`@ana/…/CoreAnalyticsManager+Extension.swift:121`):
```
applyPII(forEventDescription description, type)                  :121
  ├ let dynamicPII = storage.settings.dynamicPII                 (comes from HomeDoc override, or default)
  ├ if type ∈ dynamicPII.eventType:
  │    for regex in dynamicPII.regexPattern:
  │       desc = NSRegularExpression(pattern: regex)
  │                 .stringByReplacingMatches(in: desc, template: dynamicPII.maskedString)
  └ return desc
```

Called before `createEvent(...)` on every event (`logEvent(_:)` line 60). If the type isn't in `eventType`, description passes through untouched.

**Override from HomeDoc:** backend settings JSON should look like:
```json
"dynamicPII": {
    "regexPattern": ["\\d{9}", "\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b"],
    "eventType": ["Network", "UICustom"],
    "maskedString": "***"
}
```
Once received, `DynamicPII` fully replaces the default (it's a value, not a merge — `updateIfPresent` swaps the whole struct). To add rules without losing the MSISDN default, backend must include the default regex in the new array.

**Where to look when debugging PII:**
| Symptom | Check |
| --- | --- |
| Value not masked | Event `type` not in `dynamicPII.eventType`. Only listed types are scanned. |
| Regex not compiling | `NSRegularExpression(pattern:)` returns `nil` — the offending pattern is silently skipped. Log the regex before enabling in production. |
| Backend regex overrode defaults unexpectedly | Whole struct is replaced; server payload must re-include prior patterns. |
| Masks appearing on wrong events | Blocking rules and PII share `storage.settings` — verify `type` (`.network` / `.custom` / `.page` / …) matches `dynamicPII.eventType`. |

## Insert path
```
logEvent(_:)                         @ana/…/CoreAnalyticsManager+Extension.swift:56
  → addEvent(_:)                     @ana/…/CoreAnalyticsManager+Extension.swift:84
    → storage.addEvent(event:)       @ana/Managers/AnalyticsStorageManager.swift:113
      → eventHandler.add(event:)     @ana/Managers/EventHandler.swift:87
        ├ dataBaseManager.insert(event:appName:maxEventsInDatabase:)  @ana/…/CoreDataManager+Event.swift:13
        │   (if totalEventsInDB + 1 > maxEventsInDatabase → deleteOldEvent(with:) first)
        │   → EventModel(context:) with encrypted payload           @…/CoreDataManager+Event.swift:52
        └ checkNextFlush()           @ana/Managers/EventHandler.swift:132
```

## Flush path

Three triggers, one `flush(events:)`:

```
Trigger 1 — after every add:  EventHandler.checkNextFlush()     :132
  guard !flushInProgress
  if dbCount >= setting.flushEventCount (default 10):
     batch = min(dbCount, remainingCapacity, setting.noEventsInFlush)  (default 50 cap)
     fetchEvents(fetchLimit: .count(batch)) → flush(events:)

Trigger 2 — timer:  setFlushTimer()  :140
  Timer.scheduledTimer(timeInterval: setting.flushInterval (default 30s),
                       selector: reloadEvents,
                       repeats: true)
  reloadEvents → fetch(noEventsInFlush) → flush(events:)         :107

Trigger 3 — app backgrounded:  observer registered in start()   :77
  UIApplication.didEnterBackgroundNotification → reloadEvents

flush(events:)                                                    @ana/Managers/EventHandler.swift:150
  ├ guard !flushInProgress && !events.isEmpty
  ├ flushInProgress = true; flushTimer.invalidate()               (timer paused during flush)
  ├ remainingCapacity = setting.maxNumberOfEvents - totalEventsSent
  ├ if remainingCapacity <= 0 → log "Max Limit Reached", stop.    :161
  ├ coreAnalyticsManagerEventDelegate.maxEventbufferedDidReached(with:) { flushed in
  │     if flushed:
  │       totalEventsSent += events.count                          (UserDefaults, persistent)
  │       dataBaseManager.deleteEvents(with: transactionIDs)       :168 → CoreDataManager+Event.swift:190
  │       checkNextFlush()                                          (drain remaining if DB still >= threshold)
  │       lastFlushDate = Date().timeIntervalSince1970             (UserDefaults, persistent)
  │     setFlushTimer()                                             (re-arm the 30s timer)
  │ }

Actual submit (called by delegate):
maxEventbufferedDidReached(with:)      @ana/…/CoreAnalyticsManager+Extension.swift:141
  ├ re-runs eventBlockingCheck per event (settings may have changed since insert)
  └ analyticsNetworkManager.flush(with: submitURL, events: allEvents, ...)
```

- **Timer is paused during flush** (`flushTimer.invalidate()` at line 156) and re-armed after the callback returns. This prevents overlapping in-flight batches.
- **`flushEventCount` (10) is not the batch size.** It's the DB-count threshold that opens the flush window. The batch size is `noEventsInFlush` (50).
- **The delegate re-runs `eventBlockingCheck`** at flush time (`+Extension.swift:151`) so a settings refresh between insert and flush can still block stale events.

## Cap enforcement — two distinct caps

1. **DB cap (`maxEventsInDatabase`, default 1000)** — enforced on **every insert**. `CoreDataManager.insert(...)` counts + evicts oldest via `deleteOldEvent(with:)` (`@…/CoreDataManager+Event.swift:151`) using an `NSBatchDeleteRequest` sorted by `timestamp` ascending. **No event is ever silently dropped — the oldest is deleted first.**
2. **Send cap (`maxNumberOfEvents`, default 3000)** — enforced on **every flush**. `remainingCapacity = setting.maxNumberOfEvents - totalEventsSent` (`EventHandler.swift:24`). At 0, `flush()` early-returns with `Max Limit Reached: 3000`. Persistence keeps happening (subject to DB cap); delivery stops.

## Reset paths

| Action | Trigger | File / Line |
| --- | --- | --- |
| Delete all events for an app | `stop()` on `EventHandler` (SDK teardown / disable) | `@ana/Managers/EventHandler.swift:82,86` → `deleteAllEvents(appName:)` |
| Purge expired events | On `start()` via `removeExpiredEvents()`; age = `noUserIdEventAge * secsInDay` (default 28 d) | `@ana/Managers/EventHandler.swift:196` |
| Evict oldest to make room | On every insert when DB > cap | `@ana/…/CoreDataManager+Event.swift:22,42,151` |
| Delete flushed events by `transactionID` | After successful flush | `@ana/…/CoreDataManager+Event.swift:190` |
| `totalEventsSent` reset (send-cap counter) | On explicit `AnalyticsStorageManager` reload path @ `@ana/Managers/AnalyticsStorageManager.swift:100`. **No time-based auto-reset in code today** — it grows across sessions until wiped. |

## Where to look when debugging

| Symptom | Check |
| --- | --- |
| Numbers differ from expectation (e.g. 15/15) | Defaults are **10/30/50/1000/3000**. Check `AnalyticsSetting.swift` defaults AND that backend key names match `CodingKeys` at `AnalyticsSetting.swift:51`. |
| Backend override ignored | JSON key mismatch — `updateIfPresent` at `AnalyticsSetting.swift:47` silently falls back to default when key not present. |
| Settings never refreshed | 7-day throttle at `CoreManager.swift:245`. Force refresh via `resetEnvironment(environment:)` (`@core/…/CoreManager.swift:210`) which nulls `lastTimeSetup`. |
| First-launch has no settings | HomeDoc/settings requests failed AND no cached copy. Check `storage.getSavedSettings()` at `@core/Managers/StorageManager.swift:82`; fall-through uses `AnalyticsSetting()` defaults. |
| Events in DB but nothing sent | `remainingCapacity <= 0` (3000 cap hit) → `EventHandler.swift:161` `Max Limit Reached`. |
| DB grows past 1000 | Eviction path failing — check `deleteOldEvent(with:)` in `CoreDataManager+Event.swift:151`. |
| Flush never triggers | Timer failed to schedule (`setFlushTimer()` runs on main queue) OR `flushInProgress` stuck true after a delivery error — search for `flushInProgress = false` reset sites in `EventHandler.swift`. |
| Duplicate delivery to backend | Delete path failed after successful flush — `deleteEvents(with:transactionIDs:)` @ `CoreDataManager+Event.swift:190`. |
| Only 50 sent when 500 pending | By design — `noEventsInFlush = 50`. `checkNextFlush()` is re-called after each successful flush to drain the rest. |
| PII not masked | Event's `type` not in `dynamicPII.eventType`; only listed types are scanned. See PII section above. |
| Events survive across app kill | Yes — CoreData store is on-disk (`NSSQLiteStoreType`, file protection `.none`) at `CoreDataManager.swift:37,60`. `EventHandler.start()` picks them up next launch. |

## Enhancing

- **Force fresh settings** (bypass 7-day throttle) → `SecLib.getInstance(...)?.setEnvironment(environment:)` which calls `resetEnvironment` (`@core/…/CoreManager.swift:210`) and re-runs `setupEnvironment` immediately.
- **Add a new backend-tunable field** → add property + default on `AnalyticsSetting`, add case to `CodingKeys` with the exact backend JSON key, call `updateIfPresent(&newField, ...)` in `init(from:)`. That's the whole override contract.
- **Per-week rolling send cap** → in `EventHandler` add a window check comparing `lastFlushDate` with a 7-day boundary and zero `totalEventsSent` before evaluating `remainingCapacity`. Persist the window-start alongside `lastFlushDate` in `UserDefaults` (see `UserDefaults+Values.swift`).
- **Add a PII rule without losing MSISDN default** → backend must send the full `dynamicPII` struct including the original `"\\d{9}"` pattern; the struct is replaced whole, not merged.
- **Change defaults for a specific market app** → change the HomeDoc / settings JSON (backend controlled), not the constants in `AnalyticsSetting.swift` or `DynamicPII.swift`.
- **Add a new persisted field on Event** → extend `EventModel` in `SecLibDB.xcdatamodeld` (bump CoreData model version, add mapping — `shouldInferMappingModelAutomatically = true` already set at `CoreDataManager.swift:56`).
- **Swap CoreData for a different store** → implement `PersistentDataManager` (`@ana/…/CoreDataManager.swift:14`), inject via `SecLib.coreData` at `@ana/Managers/SecLib+Analytics.swift:13`. `logEvent(_:)` doesn't change.

## Related
Funnel in: [../AnalyticsManager/](../AnalyticsManager/copilot-setup-logEvent.md) · Auto sources: [../AutoInstrumentation/](../AutoInstrumentation/copilot-auto-instrumentation.md) · [../NetworkMonitor/](../NetworkMonitor/copilot-network-monitor.md) · [../LogCustomEvent/](../LogCustomEvent/copilot-log-custom-event.md)
