# Multi-Instance (`SecLib` per `appName`)

The SDK supports **multiple `SecLib` instances in the same process**. Each is keyed by a unique `appName` (default `"Default"` from `Constants.defaultAppName` at `@core/CoreUtility/Constants.swift:35`). Read this doc before writing any new feature — the two lists below tell you what is per-instance vs shared.

## Creating and retrieving instances
```swift
// Create — will throw if `name` is already used
let s1 = try SecLib.setup(withConfiguration: config1, name: "Market-EG")     // @core/SecLib/SecLib.swift:55
let s2 = try SecLib.setup(withConfiguration: config2, name: "Market-DE")     // (throws SecLibInstanceErrors.isUsed on duplicate)

// Retrieve later
let sX = SecLib.getInstance(withName: "Market-EG")                            // @core/SecLib/SecLib.swift:116
let sDefault = SecLib.getInstance()                                           // falls back to "Default"
```
- Instances registered in `SecLib.Instances: [String: SecLib]` (`@core/SecLib/SecLib.swift:18`).
- Guarded by `instanceCheck(name:)` (`SecLib.swift:292`) → throws `SecLibInstanceErrors.isUsed` if the same name is reused.
- Analytics-side twin stored in `SecLib.analyticsManagers: [String: CoreAnalyticsManager]` (`@ana/Managers/SecLib+Analytics.swift:15`); populated by `SecLib.configure(with:core:)` at line 26.

## What is PER-INSTANCE (isolated by `appName`)

| Thing | Where | Isolation mechanism |
| --- | --- | --- |
| `SecLib` object | `SecLib.Instances[appName]` @ `@core/SecLib/SecLib.swift:18` | keyed dict |
| `CoreManager` (Core mediator) | one per `SecLib`, held in `secLib.core` | fresh instance per setup |
| `CoreAnalyticsManager` (Analytics mediator) | `SecLib.analyticsManagers[appName]` @ `@ana/Managers/SecLib+Analytics.swift:15,48` | keyed dict |
| `EventHandler` (flush controller) | one per `CoreAnalyticsManager`, uses queue `com.vodafone.SecLib.EventHandler-<appName>` @ `@ana/Managers/EventHandler.swift:60` | per-instance init |
| `UserDefaults` suite | `SecLibUserDefaults-<appName>` @ `@core/…/CoreManager.swift:95` + `@ana/…/CoreAnalyticsManager.swift:97` | one suite per app |
| Persisted `totalEventsSent`, `lastFlushDate` | inside per-instance UserDefaults suite | isolated automatically |
| Persisted HomeDoc + Settings cache | `CoreStorageManager` per `CoreManager` (`@core/Managers/StorageManager.swift`) | per-instance disk record |
| CoreData rows (`EventModel`) | **shared store, `appName` column** — every insert / fetch / delete / count uses `appName == %@` predicate @ `@ana/…/CoreDataManager+Event.swift:74,85,131,163,191` | row-level partition |
| Config (`Configuration` / `AnalyticsConfiguration`) | passed at setup, held on the instance | per-instance value |
| Environment + submit URL (`analyticsURLs.submitEventURL`, `submitAppHangURL`) | fetched from that instance's HomeDoc | per-instance HTTP resource |
| Runtime settings (`AnalyticsSetting`) | overridden from that instance's HomeDoc → Settings request | per-instance override |
| DispatchQueue for network / core | `com.vodafone.SecLib.Core-Manager-<appName>` @ `@core/…/CoreManager.swift:98` | per-instance queue label |
| Notifications with `-<appName>` suffix | `Notifications.logCustomEvent + "-" + appName` (`@core/SecLib/SecLib.swift:282`)<br>`Notifications.networkEventData + "-" + appName` (`@core/Analytics/Managers/NetworkTrackingManager.swift`)<br>`Notifications.didReceiveHomeDocNotification + "-" + appName` (`@core/…/CoreManager.swift:238`) | routed only to matching observer |
| Custom UI Trace `event-group` value | field on `CoreAnalyticsManager` @ `@ana/…/CoreAnalyticsManager.swift:134` | per-instance |
| Ignored domains, obfuscation lists, `tidKey` | stored on the instance's `CoreManager` / `NetworkTrackingManager` | per-instance |
| Screen name (`currentScreenName`) | `CoreManager.currentScreenName` @ `@core/…/CoreManager.swift:218` | per-instance (though all instances see the same visible VC) |

## What is SHARED across all instances

| Thing | Where | Why |
| --- | --- | --- |
| Method swizzling (URLSession, UIControl, VC lifecycle, TableView/CollectionView, UIScene) | installed once at `+load` → `Core.enableSwizzling()` @ `@core/Managers/Core.swift:18` | class-level, cannot be per-instance |
| Session ID | `SecLib.sessionIDManager: SessionIDManaging` (private static) @ `@core/SecLib/SecLib.swift:20` | one user session for the whole app |
| CoreData persistent store | `SecLib.coreData: PersistentDataManager` (static) @ `@ana/Managers/SecLib+Analytics.swift:14`, initialized once in `SecLib.configure(...)` at line 39 | shared file, rows partitioned by `appName` |
| Event notification centers | `SecLib.globalNotificationCenter`, `SecLib.eventNotificationCenter` (both `NotificationCenter.default`) @ `@core/SecLib/SecLib.swift:16` + `@ana/Managers/SecLib+Analytics.swift:16` | broadcast bus |
| `UIViewControllerHangMonitor` | `SecLib.uiHangMonitor` (static) @ `@ana/Managers/SecLib+Analytics.swift:17` | one per-VC identity map is enough |
| `AppHangMonitor` | `SecLib.appHangMonitor` (static) @ `@ana/Managers/SecLib+Analytics.swift:18` | one main-thread watchdog is enough |
| `ViewControllerCalculator` | `SecLib.viewControllerCalculator` (static) @ `@ana/Managers/SecLib+Analytics.swift:20` | one set of `viewDidLoad/viewDidAppear/viewWillDisappear` observers |
| Registered `SecLibrary` components (Analytics, Crashes, CustomerChannel) | `SecLib.components: [SecLibrary]` (static) @ `@core/SecLib/SecLib.swift:17` | registered once per module |

## Broadcast events vs. addressed events

`NotificationCenter` traffic falls into two shapes:

1. **Addressed to one instance** — names end in `-<appName>`. Only that instance's observer fires. Used for:
   - `logCustomEvent` → observer at `@ana/…/CoreAnalyticsManager.swift:293`
   - Network monitor (`networkEventData`) → observer at `@ana/…/CoreAnalyticsManager.swift:158`
   - HomeDoc receive → observer at `@ana/…/CoreAnalyticsManager.swift:221`

2. **Broadcast to all instances** — no `-<appName>` suffix. Every `CoreAnalyticsManager` with the observer receives them. Used for:
   - `Notifications.interactionEvent` (UIControl, TableView, CollectionView, SwiftUI, screen load/stay time) → observer at `@ana/…/CoreAnalyticsManager.swift:283` (only registered when `analyticsConfiguration.viewLifeCycleTrackedEnabled == true`)
   - `Notifications.appLifeCycle` → observer at `@ana/…/CoreAnalyticsManager.swift:276`
   - `Notifications.smapiEnabled` → observer at `@ana/…/CoreAnalyticsManager.swift:283`; **filters by `appName` inside the handler** (`isEnabled(_:)` @ `CoreAnalyticsManager.swift:335`)

> Implication: a single UIControl tap is logged **once per instance** whose `viewLifeCycleTrackedEnabled == true`. Two instances = two `EventModel` rows with the same content but distinct `appName`. Design intent — each instance ships to its own backend.

## Contract for every NEW feature — respect multi-instance

When adding a feature, decide up front whether it is per-instance or shared, and follow the matching rules.

### Per-instance feature (default choice)
1. Store state on `CoreAnalyticsManager` (or `CoreManager` for pure-Core features), **not** in a `static var`.
2. Public API on `SecLib` (or `SecLib+Analytics`) must forward via `getAnalytics()?.…` (`@ana/Managers/SecLib+Analytics.swift:51`) or `self.core.…`. That's how you land on the caller's instance.
3. If it posts a notification, suffix the name with `-\(appName)` — pattern: `Notifications.<name> + "-" + appName`.
4. If it observes an addressed notification, register with the same `-\(appName)` suffix and unregister in `removeEventObservers()` (`@ana/…/CoreAnalyticsManager.swift:257`).
5. If it persists to `UserDefaults`, use the instance's suite: `UserDefaults(suiteName: "SecLibUserDefaults-\(appName)")` — do **not** touch `UserDefaults.standard`.
6. If it persists to CoreData, add `appName` to the predicate on every read / write / delete — mirror `CoreDataManager+Event.swift:74`.
7. Anything with a network dispatch must use the instance's `analyticsURLs` (per-instance HomeDoc-resolved URL), not a hard-coded endpoint.

### Shared / class-level feature (rare — needs a reason)
1. Only justified when the underlying resource is inherently single (a swizzle, the main thread, the CoreData file, the session ID).
2. Store as a `static` on `SecLib` extension, mirroring `uiHangMonitor` / `appHangMonitor` / `viewControllerCalculator` / `coreData`.
3. If it emits events, **broadcast** (no `-<appName>` suffix) and let each `CoreAnalyticsManager` decide whether to log — or filter by `appName` inside the handler (see `isEnabled(_:)` @ `CoreAnalyticsManager.swift:335` for the pattern).
4. Document explicitly in the feature doc that "this state is shared across all instances" — otherwise the next reader assumes per-instance.
5. Never leak per-instance secrets (submit URLs, custom user IDs, HomeDoc contents) into shared state.

## Where to look when debugging

| Symptom | Check |
| --- | --- |
| Second `setup` throws `isUsed` | Same `appName` reused — `instanceCheck(name:)` @ `@core/SecLib/SecLib.swift:292`. Call `getInstance(withName:)` instead of re-setup. |
| API call has no effect on the "wrong" instance | `getAnalytics()` looked up the wrong `appName` — `SecLib.analyticsManagers[appName]` returned `nil` (silent) or a different instance. Verify the `SecLib` you're calling on. |
| Custom / network event received by the wrong instance | Notification name suffix mismatch. Grep for `Notifications.<name> + "-" +` and verify both post and observer use the same `appName`. |
| UIControl tap logged twice | Two instances have `viewLifeCycleTrackedEnabled == true` and both observe `Notifications.interactionEvent`. That's by design — expected multi-instance behavior. If undesired, disable on the secondary instance. |
| `totalEventsSent` reaches 3000 too fast | Per-instance counter — each instance has its own send cap. If you're seeing it globally, you're mixing counters somewhere. |
| Session ID changes affect only one instance | Doesn't happen — `sessionIDManager` is static; a rotation applies globally. |
| App-hang / UI-hang alerts duplicated | Only one monitor exists; if two instances both flush hang events, that's the intended per-instance shipping, not duplicate detection. |
| CoreData grows even after `stop()` on one instance | `stop()` deletes rows only for `appName` (`@ana/Managers/EventHandler.swift:82,86`); other instances' rows remain. |
| Sample app can't isolate two markets | Both must use unique `appName` at `setup(…, name:)`; default `"Default"` collides. |

## Related
- **SDK setup / configuration** (where `SecLib.setup(...)` creates the per-instance state described above): [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Module fan-out at setup: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).
- Public-API surface + instance lookup pattern: [../../copilot-instructions.md](../../copilot-instructions.md) §2 modularity rule.
- Event storage (row-level partition by `appName`): [../EventStorage/copilot-event-storage.md](../EventStorage/copilot-event-storage.md).
- Notification wiring in observer setup: [../AnalyticsManager/copilot-setup-logEvent.md](../AnalyticsManager/copilot-setup-logEvent.md).
- Shared swizzling layer: [../AutoInstrumentation/copilot-auto-instrumentation.md](../AutoInstrumentation/copilot-auto-instrumentation.md).
- Session ID (shared across instances): [../SessionID/copilot-session-id.md](../SessionID/copilot-session-id.md).
- Auto UI hang / app hang (shared monitors): [../UIHangs/copilot-ui-hangs.md](../UIHangs/copilot-ui-hangs.md) · [../AppHang/copilot-app-hang.md](../AppHang/copilot-app-hang.md).
