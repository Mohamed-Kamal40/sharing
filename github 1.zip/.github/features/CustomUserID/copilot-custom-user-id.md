# Custom User ID

Set / read the User ID stamped on every event. The SDK **hashes the input to SHA-256** before storing.

## Public API (entry points)
| API                                     | File / Line                                                        |
| --------------------------------------- | ------------------------------------------------------------------ |
| `setUserID(userID:) -> String?`         | `CoreSDK/SecLibCore/SecLib/SecLib.swift:133`                       |
| `getUserID() -> String?`                | `CoreSDK/SecLibCore/SecLib/SecLib.swift:138`                       |
| Delegating handler                      | `CoreSDK/SecLibCore/Managers/CoreManager/CoreManager.swift:290` (`setUserID`) |
| Getter                                  | `CoreSDK/SecLibCore/Managers/CoreManager/CoreManager+CoreManagerInfoDelegate.swift:23` |
| Read into events                        | `CoreManager+CoreManagerInfoDelegate.swift:48,60` (`self.getUserID() ?? Constants.notAvailable`) |

**Module:** pure `@core` — no Analytics dependency.

## Setter contract
`CoreManager.setUserID(userID:) -> String?` (`@core/…/CoreManager.swift:290`):
1. Trim whitespace; must be non-empty and ≤ 256 chars, else stores `nil` and returns `nil`.
2. Otherwise: `let hashedID = userID.sha256(); self.userID = hashedID; return hashedID`.

So the return value is the **hashed** value that was stored, or `nil` if input was rejected.

## Call graph
```
SecLib.setUserID(userID:)              @core/SecLib/SecLib.swift:133
  → CoreManager.setUserID(userID:)     @core/Managers/CoreManager/CoreManager.swift:290
    → validate + SHA-256 hash + store

SecLib.getUserID()                     @core/SecLib/SecLib.swift:138
  → CoreManager.getUserID()            @core/Managers/CoreManager/CoreManager+CoreManagerInfoDelegate.swift:23
```

## Where to look when debugging
| Symptom                                     | Check                                                                    |
| ------------------------------------------- | ------------------------------------------------------------------------ |
| Setter returns `nil` for a real ID          | Empty after trim, or > 256 chars — see `CoreManager.swift:293-296`       |
| Value stored ≠ what I passed in             | **Expected** — SHA-256 is applied at `CoreManager.swift:298`. Docs should say "SDK hashes the value." |
| `x-vf-user-id` in events is `NA`            | `userID` unset → falls back to `Constants.notAvailable` at `CoreManager+CoreManagerInfoDelegate.swift:48,60` |
| Reset to auto-generated                     | Pass `nil` to `setUserID` → sets stored value to `nil` (`CoreManager.swift:295`) |

## Enhancing
- If you need a raw-value setter for internal test/debug, add a private setter on `CoreManager` and expose it only to test targets.
- `sha256()` extension lives in `@util` — search there before adding a duplicate helper.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Session identity: [../SessionID/copilot-session-id.md](../SessionID/copilot-session-id.md)
