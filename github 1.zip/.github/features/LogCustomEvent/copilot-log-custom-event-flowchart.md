flowchart TD
%% --- Core SDK ---
subgraph Core_SDK[Core SDK]
    A[App Calls SecLib.logCustomEvent]
    A --> B[SecLib Validates & Packages EventData]
    B --> C[SecLib.postNotificationForLogCustomEvent]
    C --> D[Post Notifications.logCustomEvent]
end

%% --- Analytics SDK ---
subgraph Analytics_SDK[Analytics SDK]
    D --> E[SecLibAnalytics Observes Custom Event]
    E --> F[CoreAnalyticsManager.receiveLogCustomEventsInfo]
    F --> G[logEvent]
    G --> H[Apply PII Masking]
    H --> I[Create Event]
    I --> J[Log to Console]
    J --> K[Add Event to Queue]
    K --> L[Persist Event coreStorageManager]
    L --> M[Schedule Flush eventHandler]
    M --> N[Flush Events to Backend]
end
