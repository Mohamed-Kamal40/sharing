# Log Custom Event

Log an app-defined event that flows through the standard event pipeline and lands in the analytics DB / dashboard.

**Backend note:** custom event types must be pre-registered on the DB side.

## Public API (entry points)
| API                                                                     | File / Line                                    |
| ----------------------------------------------------------------------- | ---------------------------------------------- |
| `logCustomEvent(withEventElement:eventDescription:onPage:onSubPage:withCustomJSONFields:)` | `CoreSDK/SecLibCore/SecLib/SecLib.swift:214` |
| `logEvent(withEventType:eventElement:eventDescription:onPage:onSubPage:hangDuration:withCustomJSON:)` (deprecated → use `logCustomEvent`) | `CoreSDK/SecLibCore/SecLib/SecLib.swift:259` |
| Private post helper                                                      | `CoreSDK/SecLibCore/SecLib/SecLib.swift:281` (`postNotificationForLogCustomEvent(eventData:)`) |

**Module:** `@core` publishes; `@ana` observes. Cross-module coupling is via `NotificationCenter`.

## Call graph
```
SecLib.logCustomEvent(...)                              @core/SecLib/SecLib.swift:214
  ├ UtilityManager.whiteSpaceValidation(inArray: […])   (from @util)
  ├ builds EventData(type: .custom, …)                  @core/Analytics/Models/EventData.swift
  └ postNotificationForLogCustomEvent(eventData:)       @core/SecLib/SecLib.swift:281
      └ NotificationCenter.default.post(
          name: <Notifications.logCustomEvent>-<appName>,   (see @core/CoreUtility/Constants.swift:41)
          userInfo: [Notifications.logCustomEvent: eventData]
        )

CoreAnalyticsManager.addEventObservers()                 @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:273
  └ addObserver(selector: receiveLogCustomEventsInfo(_:))  registered at line 293
      └ receiveLogCustomEventsInfo(_:)                    @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:350
          └ extracts EventData from userInfo[Notifications.logCustomEvent]
              → self.logEvent(_ eventData:)               @ana/Managers/AnalyticsManager/CoreAnalyticsManager+Extension.swift:56
                (guard `enabled && coreManager.smapiEnable`; PII mask; createEvent → queue → CoreData → flush)
```

See [../AnalyticsManager/copilot-setup-logEvent.md](../AnalyticsManager/copilot-setup-logEvent.md) for what happens once `logEvent(_:)` fires.

## Notification wiring
- **Name:** `Notifications.logCustomEvent + "-" + appName` — declared at `@core/CoreUtility/Constants.swift:56` (value `"logCustomEventNotification"`).
- **appName suffix** is per-`SecLib` instance — that's how multiple `SecLib` instances stay isolated.
- **userInfo key:** `Notifications.logCustomEvent` → `EventData`.

## Where to look when debugging
| Symptom                                     | Check                                                                     |
| ------------------------------------------- | ------------------------------------------------------------------------- |
| Event never reaches DB                      | Analytics module observer not registered — verify `CoreAnalyticsManager.setup()` ran; observer wiring at `CoreAnalyticsManager.swift:273`. |
| Multiple instances: wrong instance receives | Notification name is per-`appName` — check `SecLib.appName` matches on caller and observer. |
| `event-element` or `event-description` stripped | `UtilityManager.whiteSpaceValidation` at `SecLib.swift:220`. |
| Custom fields missing on backend            | JSON dict passed to `withCustomJSONFields:` must contain JSON-serializable values only; fields flow through `EventData.customJSON` → `Event.generatePayload()` → prefixed as `x-vf-custom-<key>`. |
| `hangDuration` param needed                 | Only the deprecated `logEvent(...)` at `SecLib.swift:259` takes it; `logCustomEvent` does not. |

## Enhancing
- To add a new field, extend `EventData` (`@core/Analytics/Models/EventData.swift`) and mirror the change in `Event`/payload code in `@ana/Model/Event.swift`.
- To support a new `EventCategory`, edit the enum at `@core/Analytics/Utilities/Enums/EventConstants.swift`.
- **Do not** post the custom-event notification from anywhere except `SecLib` — the observer name convention depends on `appName`.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Downstream event pipeline: [../AnalyticsManager/copilot-setup-logEvent.md](../AnalyticsManager/copilot-setup-logEvent.md)
- Flow diagram: [copilot-log-custom-event-flowchart.md](copilot-log-custom-event-flowchart.md)
- Grouping events with `event-group`: [../CustomUITrace/copilot-custom-ui-trace.md](../CustomUITrace/copilot-custom-ui-trace.md)
