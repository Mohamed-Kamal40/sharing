# Ignored Domains

Exclude specific domains and their subdomains from auto network-monitor capture.

## Public API (entry point)
- **File:** `SecLibAnalytics/Managers/SecLib+Analytics.swift:122`
- **Signature:** `@objc func throtleLocalEndPoint(endPoint: [String])`

## Call graph
```
SecLib.throtleLocalEndPoint(endPoint:)                          @ana/Managers/SecLib+Analytics.swift:122
  → CoreAnalyticsManager.setCustomIgnoredDomains(with:)         @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:177
    → coreManager.setCustomIgnoredDomains(with:)                @ana/…/CoreAnalyticsManager.swift:178   (delegate → @core)
      → CoreManager (Core mediator)                             @core/Managers/CoreManager/CoreManager.swift
        → NetworkTrackingManager (applies filter)               @core/Analytics/Managers/NetworkTrackingManager.swift
```

## Pattern rules
- `*` = wildcard matcher used inside `NetworkTrackingManager` — e.g. `"*.google.com"` matches `google.com`, `www.google.com`, `maps.google.com`.
- Multiple patterns can be passed in one call.

## Where to look when debugging
| Symptom                                     | Check                                                             |
| ------------------------------------------- | ----------------------------------------------------------------- |
| Domain still captured                       | Pattern typo, or manual `logResponse` path (filter is auto-only) — see [../ManualNetworkEvent/copilot-manual-network-event.md](../ManualNetworkEvent/copilot-manual-network-event.md) |
| All domains suddenly ignored                | Empty-string pattern behaves as match-all — validate input        |
| Config lost after re-setup                  | Setting is held on the current `CoreAnalyticsManager` — a new setup rebuilds it (`SecLib+Analytics.swift:26 configure(...)`); reapply after re-setup |

## Enhancing
- Pattern engine is inside `NetworkTrackingManager` (`@core`). Any richer syntax (e.g. regex) should be added there, and the change must respect that this file lives **in Core** but is fed by Analytics.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Auto capture: [../NetworkMonitor/copilot-network-monitor.md](../NetworkMonitor/copilot-network-monitor.md)
