# Measure Load Time / App Launch

Time an arbitrary event window (e.g. app launch, screen load) between paired `startTimer` / `stopTimer` calls.

## Public API (entry points)
| API                                                                       | File / Line                                                     |
| ------------------------------------------------------------------------- | --------------------------------------------------------------- |
| `startTimer(eventElement:uniqueCode:currentEpoch:)`                       | `SecLibAnalytics/Managers/SecLib+Analytics.swift:84`            |
| `stopTimer(uniqueCode:currentEpoch:)`                                     | `SecLibAnalytics/Managers/SecLib+Analytics.swift:98`            |
| Manager protocol (contract)                                               | `SecLibAnalytics/Managers/AnalyticsManager/AnlyticsManagerProtocol.swift:22-23` |
| Manager impl                                                              | `SecLibAnalytics/Managers/AnalyticsManager/CoreAnalyticsManager.swift:150,154` |

## Types
| Symbol                   | File                                                              |
| ------------------------ | ----------------------------------------------------------------- |
| `UptimeCalculator` (protocol) | `@ana/Managers/UptimeCalculation/UptimeCalculator.swift:12`  |
| `UptimeCalculation` (class)   | `@ana/Managers/UptimeCalculation/UptimeCalculation.swift:11` |
| `UptimeCalculationData`       | `@ana/Model/UptimeCalculationData.swift` (fields: `eventType: String`, `baseCode: Int`, `epochTime: Double`) |

## Call graph
```
SecLib.startTimer(eventElement:uniqueCode:currentEpoch:)   @ana/Managers/SecLib+Analytics.swift:84
  → CoreAnalyticsManager.startTimer(...)                   @ana/…/CoreAnalyticsManager.swift:150
    → UptimeCalculation.startEventTimer(eventType:baseCode:epochTime:)  @ana/Managers/UptimeCalculation/UptimeCalculation.swift:20
      └ completeMessageList.append(UptimeCalculationData(...))          @…/UptimeCalculation.swift:25

SecLib.stopTimer(uniqueCode:currentEpoch:)                 @ana/Managers/SecLib+Analytics.swift:98
  → CoreAnalyticsManager.stopTimer(...)                    @ana/…/CoreAnalyticsManager.swift:154
    → UptimeCalculation.stopEventDifferenceTimer(baseCode:epochTime:)   @…/UptimeCalculation.swift:28
      ├ finds entry by baseCode                             @…/UptimeCalculation.swift:30
      ├ computes diff (epochTime - stored.epochTime)
      ├ if diff > 0 → build EventData(type: .application, element: eventType, description: "<sec> sec")
      │   → self.logEvent(EventData)                         @ana/…/CoreAnalyticsManager+Extension.swift:56
      └ removes entry                                       @…/UptimeCalculation.swift:46
```

## Emitted event shape
```json
{
  "event-type": "Application",
  "event-element": "App Launch",
  "event-description": "43.000 sec"
}
```

## Where to look when debugging
| Symptom                                       | Check                                                                    |
| --------------------------------------------- | ------------------------------------------------------------------------ |
| `stopTimer` produces no event                 | `uniqueCode` doesn't match any start entry — for-loop at `UptimeCalculation.swift:30` finds nothing. |
| Duration is 0.000 sec or negative             | `currentEpoch` at stop ≤ start; `stopEventDifferenceTimer` only logs when `diff > 0`. |
| Event never reaches DB                        | `logEvent(_:)` early-return at `CoreAnalyticsManager+Extension.swift:56` (`enabled && coreManager.smapiEnable`). |
| Leaked entries in `completeMessageList`       | `startTimer` called without a matching `stopTimer`. To purge all, `UptimeCalculation.swift:51 removeAll()` (currently no public reset — expose one if needed). |
| Overlapping timers with same `uniqueCode`     | Iteration matches the first entry; add uniqueness assertion in `startEventTimer` if this is a real risk. |

## Enhancing
- Change emitted event type from `.application` to a new category in `CoreAnalyticsManager.stopTimer` (`@ana/…/CoreAnalyticsManager.swift:154`).
- To auto-time app launch, call `startTimer` from `didFinishLaunchingWithOptions` and `stopTimer` from a first-VC `viewDidLoad` (see docx for the AppDelegate/SwiftUI patterns).

## Testing
- `SecLibAnalyticsTests/UptimeCalculation/UptimeCalculationTest.swift` — start, stop, and reset paths.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- **Automatic** per-VC screen load time + stay time (no start/stop needed): [../AutoInstrumentation/copilot-auto-instrumentation.md](../AutoInstrumentation/copilot-auto-instrumentation.md) §4.4.
- Flow diagram: [copilot-measure-load-time-flowchart.md](copilot-measure-load-time-flowchart.md)
- Downstream event pipeline + storage caps: [../AnalyticsManager/copilot-setup-logEvent.md](../AnalyticsManager/copilot-setup-logEvent.md) · [../EventStorage/copilot-event-storage.md](../EventStorage/copilot-event-storage.md)
