# Measure Load Time Feature — Flowchart 

## Flow Sequence
```mermaid
sequenceDiagram
    participant App as App/ViewController
    participant SDK as SecLibAnalytics
    participant Uptime as UptimeCalculation
    participant Delegate as CoreAnalyticsManagerDelegate

    App->>SDK: startTimer(eventElement, uniqueCode, currentEpoch)
    SDK->>Uptime: startEventTimer(eventType, baseCode, epochTime)
    Uptime->>Uptime: Add UptimeCalculationData to completeMessageList
    App->>SDK: stopTimer(uniqueCode, currentEpoch)
    SDK->>Uptime: stopEventDifferenceTimer(baseCode, epochTime)
    Uptime->>Uptime: Find matching event, calculate interval
    Uptime->>Delegate: logEvent(duration)
    Uptime->>Uptime: Remove event from completeMessageList
```

## Step-by-Step Breakdown
1. **startTimer** is called when an event begins (e.g., app launch, view load).
2. `UptimeCalculation` stores the event start data.
3. **stopTimer** is called when the event ends.
4. `UptimeCalculation` finds the matching start event, calculates the duration, and logs the result.
5. The event is removed from the list to prevent duplicate logging.

## Key Methods
- `startTimer(eventElement: String, uniqueCode: Int, currentEpoch: Double)`
- `stopTimer(uniqueCode: Int, currentEpoch: Double)`
- `UptimeCalculation.startEventTimer(eventType:baseCode:epochTime:)`
- `UptimeCalculation.stopEventDifferenceTimer(baseCode:epochTime:)`

## Testing Reference
- See `SecLibAnalyticsTests/UptimeCalculation/UptimeCalculationTest.swift` for validation of timer logic and event management.

---
_Last updated: October 27, 2025_
