# Trace ID Key Mapping

Tell the SDK which request-header key holds the app's trace ID so it can be extracted and mapped to the standardized `x-vf-trace-tid` field on captured events.

## Public API (entry point)
- **File:** `SecLibAnalytics/Managers/SecLib+Analytics.swift:170`
- **Signature:** `@objc func setTraceIdKey(traceKey: String)`

## Call graph
```
SecLib.setTraceIdKey(traceKey:)                      @ana/Managers/SecLib+Analytics.swift:170
  → CoreAnalyticsManager.tidKey = traceKey           @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:34-40
    → coreManager.tidKey (delegated)                 (set into @core CoreManager)
      → NetworkTrackingManager reads it              @core/Analytics/Managers/NetworkTrackingManager.swift
        → TrackedDataTask.generateEventDescription   @core/Analytics/Models/TrackedDataTask.swift:101
          → maps <traceKey> → x-vf-trace-tid
```

## Default trace key
- `Constants.traceId = "vf-trace-transaction-id"` at `@core/CoreUtility/Constants.swift:39` — this is a **different** header (auto-captured `x-vf-trace-transaction-id`). The **user-configurable** `tidKey` starts empty; `setTraceIdKey` fills it in.

## Where to look when debugging
| Symptom                                     | Check                                                                     |
| ------------------------------------------- | ------------------------------------------------------------------------- |
| `x-vf-trace-tid` not appearing              | Header key not present on the request — verify exact header name (case-insensitive lookup) |
| Value maps but wrong                        | Check the extraction inside `TrackedDataTask.swift:101` and its call sites |
| Only auto requests get the mapping          | Manual `logResponse` (`@ana/Model/SLRequestMetrics.swift`) also uses the same trace pipeline — inspect there if manual requests miss it |

## Enhancing
- To support multiple candidate keys, change `tidKey` from `String` to `[String]` in `CoreManager` and update the loop in `TrackedDataTask.swift:101` accordingly.

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Auto capture: [../NetworkMonitor/copilot-network-monitor.md](../NetworkMonitor/copilot-network-monitor.md)
- Manual logging: [../ManualNetworkEvent/copilot-manual-network-event.md](../ManualNetworkEvent/copilot-manual-network-event.md)
