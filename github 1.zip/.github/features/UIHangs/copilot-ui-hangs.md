# UI Hangs Tracking

Auto-detect main-thread unresponsiveness ≥ 250 ms; report cumulative hang duration per screen via a `hang-duration` attribute on the `Stay Time` `Page` event. **Off unless configured.**

## Public API (entry points)
| API                                | File / Line                                                        |
| ---------------------------------- | ------------------------------------------------------------------ |
| `setUIHangMonitor(isEnabled:)`     | `SecLibAnalytics/Managers/SecLib+Analytics.swift:185`              |
| `getUIHangStatus() -> Bool`        | `SecLibAnalytics/Managers/SecLib+Analytics.swift:200`              |
| Config: `AnalyticsConfiguration.uiHangsEnabled` (default `true`) | `SecLibAnalytics/Model/AnalyticsConfiguration.swift:21,34` |

## Setup / Configuration

Default **`true`** (on by default).

**Builder:**
```swift
let cfg = Configuration.Builder()
    .addConfiguration(AnalyticsConfiguration(uiHangsEnabled: true))
    .build()
```

**JSON (`smapi-config.json`):**
```json
"analytics": { "track_ui_hangs": true }
```
> ⚠️ JSON key is `track_ui_hangs`, not `uiHangsEnabled` — see `CodingKeys` @ `@ana/Model/AnalyticsConfiguration.swift:50`.

Runtime toggle: `secLib.setUIHangMonitor(isEnabled: false)`.

Full setup flow: [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md) · Config handshake into `CoreAnalyticsManager`: [../ModuleRegistration/copilot-module-registration.md](../ModuleRegistration/copilot-module-registration.md).

## Call graph
```
SecLib.setUIHangMonitor(isEnabled:)          @ana/Managers/SecLib+Analytics.swift:185
  → CoreAnalyticsManager.analyticsConfiguration.uiHangsEnabled = …
  → uiHangEnabling()                         @ana/Managers/SecLib+Analytics.swift:190
    → ViewControllerCalculator.startUIHangMonitoring()   @ana/Managers/ViewContollerCalculation.swift:221
    │ (if any instance still has it enabled)
    └ ViewControllerCalculator.stopUIHangMonitoring()    @ana/Managers/ViewContollerCalculation.swift:225

UIViewControllerHangMonitor            @ana/Managers/HangManager/UIViewControllerHangMonitor.swift
  → hangDuration recorded per screen
    → event emitted with:              @ana/Managers/ViewContollerCalculation.swift:206
      "hang-duration": <ms>
```

## Sample event (`Stay Time`)
```json
{
  "event-type": "Page",
  "event-element": "Stay Time",
  "event-description": "18.092 sec",
  "page-name": "UINavigationController",
  "hang-duration": 300
}
```

## Where to look when debugging
| Symptom                                | Check                                                             |
| -------------------------------------- | ----------------------------------------------------------------- |
| No `hang-duration` on events           | `getUIHangStatus() == false`; or screen accumulated zero hangs (attribute is omitted when 0) |
| Monitor never fires on second instance | Monitor is **global** — driven by `SecLib.viewControllerCalculator` (a static) in `@ana/Managers/SecLib+Analytics.swift:20`; if any instance has it enabled it stays on |
| Overhead concerns                      | Poll rate lives inside `UIViewControllerHangMonitor` and `AppHangMonitor` (both use `RepeatingTimerManager` from `@util`) |

## Enhancing
- To make the threshold configurable, add a param to `AnalyticsConfiguration` and forward it into `UIViewControllerHangMonitor`.
- Threshold is currently hardcoded at 250 ms in the monitor (see `@ana/Managers/HangManager/UIViewControllerHangMonitor.swift`).

## Related
- Longer stalls (≥ 3s discrete incidents with stack trace): [../AppHang/copilot-app-hang.md](../AppHang/copilot-app-hang.md)
- `hang-duration` is stitched into the auto `Stay Time` event — see [../AutoInstrumentation/copilot-auto-instrumentation.md](../AutoInstrumentation/copilot-auto-instrumentation.md) §4.4.
