# Custom UI Trace

Wrap events between `startUITrace(withName:)` and `endUITrace()` to add an `"event-group"` attribute to every event fired in between.

## Public API (entry points)
| API                                        | File / Line                                                            |
| ------------------------------------------ | ---------------------------------------------------------------------- |
| `startUITrace(withName:)`                  | `SecLibAnalytics/Managers/SecLib+Analytics.swift:214`                  |
| `endUITrace()`                             | `SecLibAnalytics/Managers/SecLib+Analytics.swift:226`                  |

## Call graph
```
SecLib.startUITrace(withName:)                       @ana/Managers/SecLib+Analytics.swift:214
  → CoreAnalyticsManager.setEventGroupName(groupName:)   @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:134

SecLib.endUITrace()                                  @ana/Managers/SecLib+Analytics.swift:226
  → CoreAnalyticsManager.resetUITrace()                  @ana/Managers/AnalyticsManager/CoreAnalyticsManager.swift:145
```

Both mutate a group-name field on `CoreAnalyticsManager` that the event-build pipeline reads when emitting events.

## Rules (enforced in `setEventGroupName`)
- One active trace per `SecLib` instance.
- Name must be non-empty, ≤ 150 chars (truncated).
- Must be called **after** `SecLib.setup(...)`.
- Coexists with automatic UI traces — no interference.

## Where to look when debugging
| Symptom                              | Check                                                                   |
| ------------------------------------ | ----------------------------------------------------------------------- |
| `event-group` missing on events      | `startUITrace` was called on a different `SecLib` instance (`appName` mismatch) — check `SecLib.analyticsManagers[appName]` |
| Group persists after end             | `resetUITrace()` not fired — verify the same instance is used for both calls |
| Group truncation                     | 150-char cap enforced inside `setEventGroupName` (`CoreAnalyticsManager.swift:134`) |

## Enhancing
- To support nested/multiple groups, change the field type in `CoreAnalyticsManager` from single value to stack, then update the event-emission code path (search for `event-group` under `@ana`).

## Related
- **Setup prerequisite:** SDK initialized via `SecLib.setup(...)` — see [../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md](../../instructions/SecLibCoreSetup/copilot-secLib-setupAndConfiguration.md).
- Custom event: [../LogCustomEvent/copilot-log-custom-event.md](../LogCustomEvent/copilot-log-custom-event.md)
