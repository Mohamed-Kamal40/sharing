# Setup Steps for SecLibAnalyticsSDK

This guide describes the steps required to set up SecLibAnalyticsSDK including preparing dependencies and submodules.

## 1- Checkout the Development Branch

Ensure you are working on the correct branch:

```sh
git checkout development
```

## 2- Initialize and Update Submodules

Update all submodules recursively to ensure dependencies are available:

```sh
git submodule update --init --recursive
```

## 3- Verify Dependencies Branch

Make sure all dependencies and submodules are checked out to the `development` branch. For each submodule:

```sh
git submodule foreach --recursive 'git checkout development || echo "Skipping: $name (branch not found)"'
```
