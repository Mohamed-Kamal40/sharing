---
applyTo: "**/*.swift"
description: "Function declarations & calls, closure expressions, functions vs methods. Load when writing a new function, refactoring a signature, or wiring closures/completion handlers."
mode: agent
---

# Functions & Closures (load when writing or refactoring a function)

Covers section 7 (Functions), 7.1 (Declarations), 7.2 (Calls), 7.3 (Closures), and section 9 (Functions vs Methods).

## Declarations
Short signatures on one line:
```swift
func reticulateSplines(spline: [Double]) -> Bool {
  // …
}
```
Long signatures — one parameter per line, closing `)` and `->` on a new line, extra indent:
```swift
func reticulateSplines(
  spline: [Double],
  adjustmentFactor: Double,
  translateConstant: Int,
  comment: String
) -> Bool {
  // …
}
```

## `Void` vs `()`
- Input: use `()` — `func updateConstraints()`, not `func updateConstraints(Void)`.
- Output / closure return type: use `Void` — `-> Void`, `typealias CompletionHandler = (Result) -> Void`.

## Calls
Mirror the declaration style. Single-line when it fits:
```swift
let success = reticulateSplines(splines)
```
Wrapped: one param per line, indent one level, closing `)` on the last argument's line:
```swift
let success = reticulateSplines(
  spline: splines,
  adjustmentFactor: 1.3,
  translateConstant: 2,
  comment: "normalize the display")
```

## Closures
- **Trailing closure syntax** only when there's a single closure at the end of the argument list.
- Multiple closure parameters → keep them named at the call site (avoid mixing trailing + labelled).
```swift
// Preferred
UIView.animate(withDuration: 1.0) {
  self.myView.alpha = 0
}

UIView.animate(withDuration: 1.0, animations: {
  self.myView.alpha = 0
}, completion: { finished in
  self.myView.removeFromSuperview()
})
```
- Single-expression closures with clear context → **implicit return**:
```swift
attendeeList.sort { a, b in a > b }
```
- Chained trailing closures — either compact one-liners or one call per line; keep it readable.

## Functions vs methods
Free functions are rare. Prefer a method on the appropriate type — it's more discoverable, more testable, and reads better.
```swift
// Preferred
let sorted = items.mergeSorted()
rocket.launch()

// Not preferred
let sorted = mergeSort(items)
launch(&rocket)
```
Free functions are only appropriate when there is no meaningful receiver — e.g. `zip(a, b)`, `max(x, y, z)`.

## Related
- Retain cycles in closures: [copilot-memory.md](copilot-memory.md).
- Guard-early returns instead of nested `if`s: [copilot-control-flow.md](copilot-control-flow.md).
