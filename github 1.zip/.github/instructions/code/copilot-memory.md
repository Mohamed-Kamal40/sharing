---
applyTo: "**/*.swift"
description: "Memory management — retain cycles, [weak self] / [unowned self], value types to prevent cycles. Load whenever you write a closure that captures self, a delegate property, a notification observer, or a completion handler."
mode: agent
---

# Memory Management (load when writing closures that capture `self` or delegate properties)

Covers section 10 (Memory Management) and 10.1 (Extending object lifetime).

## Rule zero — no reference cycles
Every closure that could outlive its owner must capture `self` weakly (or the escape route must be proven). Prefer value types (`struct`, `enum`) when the ownership relationship isn't clear — cycles cannot form.

## Standard idiom: `[weak self]` + `guard let self = self`
```swift
resource.request().onComplete { [weak self] response in
  guard let self = self else { return }
  let model = self.updateModel(response)
  self.updateUI(model)
}
```
- Use `[weak self]` by default. `[unowned self]` only when `self` is proven to outlive the closure.
- After `guard let self = self else { return }`, `self` is non-optional inside the closure — no more `self?.…`.

## Anti-patterns
```swift
// Might crash — [unowned self] and self could be released first
resource.request().onComplete { [unowned self] response in
  let model = self.updateModel(response)
  self.updateUI(model)
}

// Racy — self could deallocate between updateModel and updateUI
resource.request().onComplete { [weak self] response in
  let model = self?.updateModel(response)
  self?.updateUI(model)
}
```
Fix: extend the lifetime explicitly at the top with `guard let self = self else { return }` so the whole closure body sees the same non-nil `self`.

## Delegate properties on classes → always `weak`
```swift
weak var delegate: SomeDelegate?
```
Otherwise the delegator holds its host, and the host holds the delegator → cycle.

## NotificationCenter observer tokens
When registering with the block-based `addObserver(forName:object:queue:using:)`, capture `[weak self]` inside the block and store the token so you can remove it in `deinit`:
```swift
self.token = NotificationCenter.default.addObserver(forName: .foo, object: nil, queue: .main) { [weak self] _ in
  self?.handleFoo()
}
// deinit { NotificationCenter.default.removeObserver(token) }
```

## Timers
`Timer.scheduledTimer` retains its target. Either invalidate the timer explicitly in `deinit`, or use the block-based form with `[weak self]`.

## Related
- Where closures typically appear in this codebase (completion handlers, `EventHandler` flush callbacks, `RepeatingTimerManager` blocks): see `@ana/Managers/EventHandler.swift`, `@util/Managers/RepeatingTimerManager.swift`.
- Closure syntax rules: [copilot-functions.md](copilot-functions.md).
