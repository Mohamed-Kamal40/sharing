---
applyTo: "**/*.swift"
description: "Repo-specific conventions — folder layout for new files, SwiftLint. Load when creating a new file or moving files."
mode: agent
---

# Project Conventions (load when creating a new file or restructuring folders)

Covers section 17 (Project specification) and 18 (SwiftLint).

## Folder layout
When a design doc doesn't specify otherwise, create separate folders for at least:
- `ViewControllers/`
- `Models/`
- `Branding/`
- `Common/`
- `Services/`

In this repo, the module-level convention is:
- `Managers/` — coordinators / mediators
- `Model/` (Analytics) or `Models/` (Core) — data types
- `Extensions/` — Swift extensions grouped by target type
- `Utilities/` — helpers (`Enums/`, `Protocols/`, constants)

See [../../features/](../../) for the master feature index and [../../copilot-instructions.md](../../copilot-instructions.md) §2 for module path aliases (`@core`, `@core.ana`, `@ana`, `@util`).

## File header
Every new Swift file starts with:
```swift
//
//  FileName.swift
//  ProjectName
//
//  Created by <Author> on <Date>
//  Copyright © <year> Vodafone. All rights reserved.
//
```

## SwiftLint
Follow [`.swiftlint.yml`](../../../.swiftlint.yml) at repo root. All formatting/style is enforced there — do not re-argue lint-covered rules in reviews. If a lint failure is genuinely wrong, propose an amendment to `.swiftlint.yml` in the same PR rather than sprinkling `// swiftlint:disable`.

## Related
- Naming: [copilot-naming.md](copilot-naming.md)
- Formatting: [copilot-formatting.md](copilot-formatting.md)
- Where new features and their docs go: [../../copilot-instructions.md](../../copilot-instructions.md) §9 Maintenance.
- Where new SDK modules plug in: [../../features/ModuleRegistration/](../../features/ModuleRegistration/copilot-module-registration.md).
