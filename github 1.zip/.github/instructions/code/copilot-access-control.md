---
applyTo: "**/*.swift"
description: "Access modifiers — private / fileprivate / internal / public / open, and their ordering with @IBAction, @IBOutlet, @discardableResult, static, lazy. Load when adding a new property/method or changing visibility."
mode: agent
---

# Access Control (load when setting or changing a symbol's visibility)

Covers section 11 (Access Control).

## Prefer `private`; use `fileprivate` only when the compiler insists
`private` is nearly always what you want. `fileprivate` is a last resort — reach for it only when a top-level function or extension in the same file genuinely needs to see the member.

## `open`, `public`, `internal`
Set them **explicitly** only when the full access specification matters (public API surface, `open` classes intended for subclassing outside the module). Don't spell out `internal` — it's the default.

## Ordering — access control is the LEADING specifier
The only things that may come before access control are:
- `static`
- Attributes such as `@IBAction`, `@IBOutlet`, `@discardableResult`

```swift
// Preferred
private let message = "Great Scott!"

class TimeMachine {
  private dynamic lazy var fluxCapacitor = FluxCapacitor()
}
```
```swift
// Not preferred — fileprivate instead of private, and wrong specifier order
fileprivate let message = "Great Scott!"

class TimeMachine {
  lazy dynamic private var fluxCapacitor = FluxCapacitor()
}
```

## Public API surface of the SDK
Anything exposed to app code (methods on `SecLib` and its extensions, config types, `SecLibrary` protocol) must be `@objc public` where it's meant to be visible to Objective-C consumers, otherwise plain `public`. Removing / renaming a `public` symbol is a source-breaking change — treat as ABI.

## Related
- Where to place the type in its extension: [copilot-organization.md](copilot-organization.md).
- Public API changes must be coordinated with the multi-instance and module-registration contracts: [../../features/MultiInstance/](../../features/MultiInstance/copilot-multi-instance.md), [../../features/ModuleRegistration/](../../features/ModuleRegistration/copilot-module-registration.md).
