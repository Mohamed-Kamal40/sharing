---
applyTo: "**/*.swift"
description: "Classes vs structs, self, computed properties, final. Load when introducing/modifying a type declaration or property observers."
mode: agent
---

# Types (load when defining classes, structs, properties)

Covers section 6 (Classes and Structures) and 6.1–6.3 (Use of Self, Computed Properties, Final).

## Class vs struct — value vs reference semantics
- **Struct** for things without identity — coordinates, dates, ids, DTOs. Two structs holding the same fields are interchangeable.
- **Class** for things with identity or a lifecycle — `Person`, a live `View`, a manager.
- If a "struct-like" thing must conform to `AnyObject` (or is historically modelled as a class in system frameworks), use a class.

## Example — well-styled class definition
```swift
class Circle: Shape {
  var x: Int, y: Int
  var radius: Double
  var diameter: Double {
    get { return radius * 2 }
    set { radius = newValue / 2 }
  }

  init(x: Int, y: Int, radius: Double) {
    self.x = x
    self.y = y
    self.radius = radius
  }

  convenience init(x: Int, y: Int, diameter: Double) {
    self.init(x: x, y: y, radius: diameter / 2)
  }

  override func area() -> Double {
    return Double.pi * radius * radius
  }
}

extension Circle: CustomStringConvertible {
  var description: String {
    return "center = \(centerString) area = \(area())"
  }
  private var centerString: String {
    return "(\(x),\(y))"
  }
}
```
Guidelines shown:
- Type declarations use `name: Type` — space after colon, none before.
- Multiple related variables may share a line.
- Indent getter/setter bodies.
- Don't add default modifiers (`internal`) or repeat access on `override`.
- Non-shared helpers live in `private` extensions.

## Use of `self`
Omit `self` unless the compiler requires it — in `@escaping` closures or to disambiguate init arguments from properties. **If it compiles without `self`, drop it.**

## Computed properties
Read-only computed property → omit `get`. Only include `get` when a `set` is also present.
```swift
// Preferred
var diameter: Double { return radius * 2 }

// Not preferred
var diameter: Double {
  get { return radius * 2 }
}
```

## `final`
Mark a class `final` when inheritance is not intended. Signals intent to the reader and can help the optimiser.
```swift
final class Box<T> {
  let value: T
  init(_ value: T) { self.value = value }
}
```

## Related
- Access modifiers on properties: [copilot-access-control.md](copilot-access-control.md).
- Closures inside property observers / initializers: [copilot-functions.md](copilot-functions.md).
- Memory rules for reference types: [copilot-memory.md](copilot-memory.md).
