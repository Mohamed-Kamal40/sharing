---
applyTo: "**/*.swift"
description: "Loops, ternary operator, guard/golden-path, defer. Load when writing conditionals, unwrapping optionals, or refactoring nested if statements."
mode: agent
---

# Control Flow (load when writing conditionals, loops, or optional unwrap)

Covers section 12 (Control Flow), 12.1 (Ternary Operator), 12.2 (Golden Path), 12.3 (Failing Guards).

## Prefer `for-in` over `while`
```swift
// Preferred
for _ in 0..<3 { print("Hello three times") }
for (index, person) in attendeeList.enumerated() { … }
for index in stride(from: 0, to: items.count, by: 2) { … }
for index in (0...3).reversed() { … }
```
```swift
// Not preferred
var i = 0
while i < 3 { print("Hello three times"); i += 1 }
```

## Ternary — only for clarity, never chained
Use `? :` only when a single condition assigning between two values reads more clearly than an `if/else`. Two conditions → refactor.
```swift
// Preferred
let value = 5
result = value != 0 ? x : y
```
```swift
// Not preferred
result = a > b ? x = c > d ? c : d : y
```

## Golden path — left margin is the happy path
Don't nest `if let`. Use `guard` to bail early. Multiple returns are fine.
```swift
// Preferred
func computeFFT(context: Context?, inputData: InputData?) throws -> Frequencies {
  guard let context = context else { throw FFTError.noContext }
  guard let inputData = inputData else { throw FFTError.noInputData }
  // use context and input to compute the frequencies
  return frequencies
}
```
Nested `if let`/`else` for every unwrap is the anti-pattern — refactor to `guard`.

## Compound `guard` when unwrapping many optionals
```swift
// Preferred
guard
  let number1 = number1,
  let number2 = number2,
  let number3 = number3
  else {
    fatalError("impossible")
}
// do something with numbers
```

## Failing `guard` — exit with a one-liner
Every `guard` must exit: `return`, `throw`, `break`, `continue`, `fatalError()`. Keep the `else` block small.
If multiple exit paths need the same cleanup, use `defer` to avoid duplicating it.

## Related
- Optional chaining vs `guard` inside closures: [copilot-memory.md](copilot-memory.md).
- Function signatures for multi-return paths: [copilot-functions.md](copilot-functions.md).
