---
applyTo: "**/*.swift"
description: "Whitespace, braces, semicolons, parentheses, multi-line strings, emoji — load whenever formatting decisions come up. Style is also enforced by SwiftLint (.swiftlint.yml)."
mode: agent
---

# Formatting (load when touching whitespace, braces, string literals, comments)

Covers sections 4 (Spacing), 5 (Comments), 13 (Semicolons), 14 (Parentheses), 15 (Multi-line Strings), 16 (No Emoji).

**Ground truth = SwiftLint** — [`.swiftlint.yml`](../../../.swiftlint.yml). If SwiftLint and this doc disagree, SwiftLint wins. Don't re-argue formatting in reviews.

## Indentation and braces
- **4 spaces**, no tabs.
- `if / else / switch / while / func / class` open brace on the same line, close on a new line.
```swift
// Preferred
if user.isHappy {
  // …
} else {
  // …
}
```
```swift
// Not preferred — allman-style braces
if user.isHappy
{
  // …
}
```

## Blank lines
- One blank line between methods.
- Up to one blank line between type declarations for visual grouping.
- **No blank line** after `{` or before `}`.
- If you need many section breaks inside one method, refactor.

## Colons and spacing
- No space before `:`, one space after.
- Exceptions: ternary `? :`, empty dictionary `[:]`, and `#selector(addTarget(_:action:))`.
```swift
// Preferred
class TestDatabase: Database {
  var data: [String: CGFloat] = ["A": 1.2, "B": 3.2]
}
```

## Line length
Wrap around **~70 chars**. No hard limit — clarity > line count.

## Trailing whitespace
None. Add a single newline at end of file.

## Comments — explain WHY, not WHAT
- Keep comments up-to-date or delete them.
- Avoid block comments inline with code. **Exception:** DocC / doc-generation blocks.
- Don't comment out code; delete it.

## Semicolons
Never use semicolons. Never combine multiple statements on one line.
```swift
let swift = "not a scripting language"   // preferred
let swift = "not a scripting language";  // not preferred
```

## Parentheses around conditionals
Omit. `if name == "Hello" {` — not `if (name == "Hello") {`.

Parens are OK inside larger expressions when they aid clarity, e.g. `let playerMark = (player == current ? "X" : "O")`.

## Multi-line string literals
Open on the same line as the assignment; put content on a new indented line; close with `"""` on its own line indented one level less than content.
```swift
// Preferred
let message = """
    You cannot charge the flux \
    capacitor with a 9V battery.
    You must use a super-charger \
    which costs 10 credits. You have \(credits) available.
    """
```
Do not open literal text on the same line as `"""`. Do not use `+`-concatenated single-line strings for long text.

## No emoji in code
Don't insert emoji in source. They break editors, grep, and locale-aware pipelines.

## Naming refresher
Formatting decisions never override naming rules — see [copilot-naming.md](copilot-naming.md).
