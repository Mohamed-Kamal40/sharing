---
applyTo: "**/*.swift"
description: "Swift naming conventions — load when introducing/renaming types, functions, properties, protocols, delegates, generics, or when reviewing identifier choices."
mode: agent
---

# Naming (load when introducing or renaming identifiers)

Follow Swift API Design Guidelines. The rules in this file replace section 1 (Naming) and 2.1–2.5 of `copilot-code-instructions.md`.

## Core rules
- **Case:** `camelCase` for vars/funcs/params; `UpperCamelCase` for types and protocols.
- Clarity at the call site > brevity. Include needed words, drop needless ones. Use precedent (existing patterns in the codebase win).
- Name by **role**, not by type.
- **Factory methods** start with `make`.
- **Methods with side effects**: verb → non-mutating uses `-ed`/`-ing`, noun → mutating uses `formX`.
- **Boolean names** read as assertions (`isEnabled`, `hasData`).
- **Protocol names**: nouns for "what it is"; end in `-able` / `-ible` for capabilities.
- **Avoid abbreviations** — but keep acronyms/initialisms cased uniformly (`URLSession`, `userID`).
- Prefer methods/properties over free functions.
- **No overloads on return type.** Give parameters good names — they are documentation. Label closure and tuple params.
- Take advantage of default parameter values.

## No class prefixes
Swift auto-namespaces by module. **Do not** prefix types (`VF…`, `SL…` are wrong for new types). Disambiguate only when a real collision requires `ModuleName.TypeName`.

## Delegates — unnamed first param is the source
```swift
// Preferred
func namePickerView(_ namePickerView: NamePickerView, didSelectName name: String)
func namePickerViewShouldReload(_ namePickerView: NamePickerView) -> Bool

// Not preferred
func didSelectName(namePicker: NamePickerViewController, name: String)
func namePickerShouldReload() -> Bool
```

## Type-inferred context — use the shortest form the compiler will accept
```swift
// Preferred
let selector = #selector(viewDidLoad)
view.backgroundColor = .red
let toView = context.view(forKey: .to)
let view = UIView(frame: .zero)

// Not preferred
view.backgroundColor = UIColor.red
let view = UIView(frame: CGRect.zero)
```

## Generics
Descriptive `UpperCamelCase` (e.g. `Element`, `Target`) when the parameter has a role. Use `T`, `U`, `V` only when it truly doesn't.
```swift
// Preferred
struct Stack<Element> { ... }
func write<Target: OutputStream>(to target: inout Target)
func swap<T>(_ a: inout T, _ b: inout T)
```

## Language
US English spelling to match Apple's API (`color`, not `colour`). Business-domain names may be used for module names by exception.

## Prose — how to refer to methods in comments / docs
Use the simplest unambiguous form: bare name → name with argument labels → full signature. Prefer the shortest form that isn't ambiguous.
