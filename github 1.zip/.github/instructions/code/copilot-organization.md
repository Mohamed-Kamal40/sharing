---
applyTo: "**/*.swift"
description: "File organization — load when adding/removing extensions, protocol conformances, imports, dead code, or reorganizing a file's structure."
mode: agent
---

# Code Organization (load when moving code around a file)

Covers section 3 (Code Organization), 3.1 (Protocol Conformance), 3.2 (Unused Code), 3.3 (Minimal Imports).

## Extensions grouped by responsibility, marked with `// MARK: - <name>`
Use extensions to split logical blocks. Prefer one protocol conformance per extension.
```swift
class MyViewController: UIViewController {
  // class stuff
}

// MARK: - UITableViewDataSource
extension MyViewController: UITableViewDataSource { … }

// MARK: - UIScrollViewDelegate
extension MyViewController: UIScrollViewDelegate { … }
```

Do **not** stack conformances on the class line (`class X: UIViewController, UITableViewDataSource, UIScrollViewDelegate` is discouraged).

For UIKit view controllers, consider grouping **lifecycle**, **custom accessors**, and **IBAction** in their own extensions. Whatever grouping rule the project picks, keep it consistent.

Derived classes may skip replicating base-class extension groups when overriding few methods.

## Unused / dead code
Remove template stubs, empty overrides that just call `super`, `// #warning …` placeholders. If a method isn't doing anything, delete it.
```swift
// Preferred — only real overrides survive
override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
  return Database.contacts.count
}
```
```swift
// Not preferred — bare super-call and TODO placeholders
override func didReceiveMemoryWarning() {
  super.didReceiveMemoryWarning()
}
override func numberOfSections(in tableView: UITableView) -> Int {
  // #warning Incomplete implementation
  return 1
}
```

## Minimal imports
Import only what the file needs.
- Prefer `import Foundation` when the file only uses Foundation.
- Prefer `import UIKit` when the file uses UIKit (it re-exports Foundation — don't add both).
- Don't leave stale imports after refactors.
```swift
// Preferred
import UIKit
var view: UIView
var deviceModels: [String]
```
```swift
// Not preferred
import UIKit
import Foundation
```

## File header (project convention)
Every new file:
```swift
//
//  FileName.swift
//  ProjectName
//
//  Created by <Author> on <Date>
//  Copyright © <year> Vodafone. All rights reserved.
//
```
