# Copilot Unit Testing Instructions

This guide provides best practices and naming conventions for writing new and review unit test functions in the SecLibAnalytics project. Follow these instructions to ensure consistency and clarity in your test code.

## 1. Test Function Naming Convention

- Use the following pattern for naming test functions:
  
  `func test_<methodOrFeature>_<conditionOrScenario>_return<ExpectedResult>()`

- Use underscores (`_`) to separate logical parts of the test name.
- The function name should clearly describe:
  - The method or feature under test
  - The specific condition or scenario
  - The expected result

**Example:**
```swift
func test_fetchUserProfile_networkFailure_returnError() {
    // ...test code...
}
```

## 2. Writing Test Functions

- Each test should focus on a single behavior or scenario.
- Use `XCTAssert` functions to verify expected outcomes.
- If testing asynchronous code or closures, use `XCTestExpectation`:

**Example for closure/async handling:**
```swift
func test_asyncOperation_completionHandler_called_returnTrue() {
    let expectation = self.expectation(description: "Completion handler called")
    someAsyncMethod { result in
        XCTAssertTrue(result, "Expected result to be true")
        expectation.fulfill()
    }
    waitForExpectations(timeout: 1.0)
}
```

**Note:**
Any test that asserts or verifies results inside a closure or asynchronous callback must use `XCTestExpectation` and `waitForExpectations(timeout:)` to ensure the closure is executed before the test completes.

## 3. Test Structure

- Use `setUp()` and `tearDown()` to initialize and clean up test state.
- Group related tests in a single test class.
- Use mock objects to isolate the unit under test if needed.

## 4. Test File Organization

- Place all test files in the `SecLibAnalyticsTests` folder.
- Name test files after the class or feature they test, ending with `Tests.swift` (for Swift) or `Tests.m` (for Objective-C).
- For Objective-C tests (see `SecLibAnalyticsTests.m`):
  - Use `- (void)test_<feature>_<scenario>_return<ExpectedResult>`
  - Use `XCTAssert` macros for assertions.

**Example (Objective-C):**
```objective-c
- (void)test_exampleFeature_condition_returnTrue {
    // ...test code...
    XCTAssertTrue(someCondition, @"Expected someCondition to be true");
}
```

## 5. Additional Guidelines

- Always write tests for both the main (happy path) and all early return, guard, or error/edge cases, including when required dependencies are nil or invalid. This ensures that all code paths, including negative scenarios, are covered.
- Use descriptive assertion messages to clarify failures.
- Keep tests independent and repeatable.
- Mock dependencies as needed to avoid side effects.
- For UI-related tests, use helper methods to create mock views or data.


## 6. Summary Checklist

- [ ] Name test functions using the pattern: `test_<feature>_<scenario>_return<ExpectedResult>`
- [ ] Use XCTestExpectation and waitForExpectations(timeout:) for any test that verifies results inside a closure or async code, and always provide assertion messages
- [ ] Place tests in the correct folder and file
- [ ] Use assertions to verify results, with descriptive messages
- [ ] Keep tests focused and independent

---

By following these instructions, you ensure your unit tests are clear, maintainable, and consistent with the project's standards.
