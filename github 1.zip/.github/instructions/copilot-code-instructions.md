---
applyTo: "**/*.swift"
description: "Index of Swift coding standards. Load ONLY the topic files under code/ that match the changes you are making. Agent mode only — do not consult while answering ask-mode questions."
mode: agent
---

# Copilot Code Instructions — Index

> **Agent-mode only.** These rules govern **generating and editing code** — i.e. any turn where Copilot is writing Swift into files. Do NOT consult them in **ask mode** (plain conversational questions such as "how does feature X work?" or "explain this file"). If you are only answering a question and not editing code, skip everything below.

> **Load the topic that matches your change, not this whole tree.** Each file under [`code/`](code/) is scoped to one concern and self-contained. Read only the ones the change touches. Style questions the linter already answers are settled by [`.swiftlint.yml`](../../.swiftlint.yml).

## When to load which file

| Situation (agent about to write / edit …) | Topic file | Covers |
| --- | --- | --- |
| Introducing / renaming a type, function, property, protocol, delegate, generic parameter | [code/copilot-naming.md](code/copilot-naming.md) | camelCase / UpperCamelCase, factory `make…`, boolean assertions, delegates with unnamed first param, generic naming, US English, no class prefixes |
| Moving code around a file, adding/removing extensions, protocol conformances, imports; deleting dead code | [code/copilot-organization.md](code/copilot-organization.md) | `// MARK: -` extensions, one conformance per extension, dead code, minimal imports, file header |
| Any whitespace / brace / semicolon / paren / multi-line string decision | [code/copilot-formatting.md](code/copilot-formatting.md) | 4-space indent, brace style, colon spacing, ~70-char wrap, no semicolons, no emoji. **SwiftLint is authoritative.** |
| Introducing / modifying a type declaration, `self` usage, computed property, `final` | [code/copilot-types.md](code/copilot-types.md) | struct vs class, well-styled definition, omit `self`, read-only computed omits `get`, use `final` |
| Writing / refactoring a function or closure signature or call site | [code/copilot-functions.md](code/copilot-functions.md) | single-line vs multi-line signatures, `Void` vs `()`, trailing closures, methods vs free functions |
| Writing a closure that captures `self`, a delegate property, a notification observer, a completion handler, a `Timer` | [code/copilot-memory.md](code/copilot-memory.md) | `[weak self]` + `guard let self`, `weak` delegates, avoiding `[unowned self]`, observer cleanup |
| Adding a property/method or changing visibility (`private` / `public` / `internal` / `open`) | [code/copilot-access-control.md](code/copilot-access-control.md) | prefer `private`, access as leading specifier, don't spell out `internal`, `@objc public` for ObjC-facing SDK API |
| Writing conditionals, loops, ternaries, unwrapping optionals | [code/copilot-control-flow.md](code/copilot-control-flow.md) | prefer `for-in`, golden path with `guard`, compound `guard` for many optionals, one-line `else` blocks |
| Creating a new file or moving files, or touching lint config | [code/copilot-project-conventions.md](code/copilot-project-conventions.md) | folder layout, file header, `.swiftlint.yml` as source of truth |

## Related non-coding-standards references

- **Feature index** (for how a piece of business logic hangs together, not how to style it): [../copilot-instructions.md](../copilot-instructions.md) §3.
- **Unit test conventions** (test naming, XCTestExpectation for closures/async): [copilot-unit-testing-instructions.md](copilot-unit-testing-instructions.md).
- **Submodule setup** before you start editing: [../prompt/prompt-setup-submodules.md](../prompt/prompt-setup-submodules.md).
- **Multi-instance contract** (any new feature must respect it): [../features/MultiInstance/copilot-multi-instance.md](../features/MultiInstance/copilot-multi-instance.md).
- **Module registration contract** (adding a brand-new SDK module): [../features/ModuleRegistration/copilot-module-registration.md](../features/ModuleRegistration/copilot-module-registration.md).

## Maintenance rule

- Every code-standards topic lives in exactly one file under [`code/`](code/). If a rule is missing, add it to the matching topic — do **not** re-inline content in this index.
- If a new topic is genuinely different (say, concurrency: `async`/`await` / actors) create `code/copilot-concurrency.md` with the same frontmatter shape and add a row to the table above.
- Keep each topic file short enough to load on its own (aim ≤ 150 lines). If a topic grows past that, split it before it becomes what this index was designed to replace.
