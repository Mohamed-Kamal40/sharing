# SecLib Code Design Instructions

## Design Patterns Utilized
1) Facade Pattern: `SecLib` class acts as a facade to simplify to the developer the setup and other methods to interact with the library.
2) Mediator Pattern: `CoreManager` class acts as a mediator between the different Managers like `NetworkManager, StorageManager, SettingsManager, HomeDocManager, NetworkTrackingManager, etc.....`.
3) Builder Pattern: `ConfigurationBuilder` class to build the configuration object that is used in the setup of the library.

## Setup & Init Flow (ordered)

### 1- Swizziling implementation

1) `class Core` has `startLogic()` to implement swizzling `enableSwizzling()`.
2) `CoreSecLibLoader.m` calls `[Core startLogic]` in `+load`. To implement Swizziling at early stage.

### 2- SecLib Setup

1) SecLib setup has two ways:
    - `setup(withConfiguration....` that gets called from AppDelegate.swift that gets from builder configuration.
    - `setup(withPath....` that gets called from AppDelegate.swift that gets the configuration from smapi-config.json when it is added in the root when smapi-config.json is added in a custom path.
    - `setup(withName....` that gets called from AppDelegate.swift that gets the configuration from smapi-config.json when smapi-config.json is added in the root.
2) The Previous three methods call:
    -  instance check to ensure that the setup only happens once for the same instance name.
    -  calls `setup(config:...` that does the main setup logic.
3) `setup(config:...` does the main setup logic:
    - creates the `Core` instance.
    - saves the instance in a static dictionary `instances`.
    - calls `core.startCoreLogic(completion: nil)` on the core instance.
    - configure the other modules like `Analytics, CustomerChannel, Crashes` that conforms to Seclibrary. to start their logic with their configuration.
    
### 3- Configuration

The configuration system in SecLib uses the **Builder Pattern** to create a flexible and extensible `Configuration` object, which encapsulates all SDK setup parameters. This approach ensures clarity, modularity, and type safety when initializing the SDK.

- **Configurable Protocol**: Any configuration component must conform to `Configurable`, providing a unique `key` and a `build()` method that serializes its data for inclusion in the configuration.

- **Configuration Class**: Stores the overall SDK setup, including:
    - `environment`: The target environment (GCPPRE, GCPPROD, GCPSTUBS).
    - `verboseEnabled`: Enables verbose logging for debugging and diagnostics.
    - `packageName`: Identifies the source app/package for traceability.
    - `components`: An array of component configurations, each as a dictionary.

- **Builder Class**: Used to fluently construct a `Configuration` instance:
    - Set environment, package name, and logging options.
    - Add component configurations via `addConfiguration(_:)`, ensuring no duplicate keys.
    - Call `build()` to produce a ready-to-use `Configuration` object.


