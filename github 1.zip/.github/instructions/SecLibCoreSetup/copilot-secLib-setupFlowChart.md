# Setup & Init Flow Chart
```mermaid
flowchart TD

%% ==========
%% App Launch & Swizzling
%% ==========
AppLaunch --> CoreSecLibLoader_m_load
CoreSecLibLoader_m_load --> Core_startLogic
Core_startLogic --> enableSwizzling

%% ==========
%% Setup Entry Points
%% ==========
AppLaunch --> AppDelegate_calls_SecLib_setup

AppDelegate_calls_SecLib_setup --> setup_withConfiguration
AppDelegate_calls_SecLib_setup --> setup_withPath
AppDelegate_calls_SecLib_setup --> setup_withName

%% Configuration Builder
setup_withConfiguration --> ConfigurationBuilder_builds_Configuration

%% Instance Check
setup_withConfiguration --> Instance_exists
setup_withPath --> Instance_exists
setup_withName --> Instance_exists
ConfigurationBuilder_builds_Configuration --> Instance_exists

Instance_exists -- Yes --> throwError_instace_exsists
Instance_exists -- No --> setup_config

%% ==========
%% Main Setup Logic
%% ==========
setup_config --> Create_Core_instance
Create_Core_instance --> Save_instance
Save_instance --> core_startCoreLogic
core_startCoreLogic --> Configure_modules

%% ==========
%% Managers via Mediator
%% ==========
core_startCoreLogic --> CoreManager_Mediator
CoreManager_Mediator --> NetworkManager
CoreManager_Mediator --> StorageManager
CoreManager_Mediator --> SettingsManager
CoreManager_Mediator --> HomeDocManager
CoreManager_Mediator --> NetworkTrackingManager
```
